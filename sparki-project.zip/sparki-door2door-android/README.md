# Sparki Door2Door v2

Android MVP voor deur-aan-deurverkoop.

## v2 functies
- Straat + gemeente + huisnummerbereik
- Oneven, even of alle nummers
- Snelle status per huisnummer
- Direct afspraak plannen met datum en uur
- Centrale afsprakenlijst
- Open afspraakadres in Google Maps
- Voeg afspraak toe aan Android agenda
- CSV export met afspraakdatum/-uur
- Team-backup export/import met slimme merge per huisnummer
- Bestaande v1-data blijft leesbaar

## Team delen
De teamfunctie wisselt een JSON-backup uit. De nieuwste wijziging per huisnummer wint bij import. Dit is geen live cloud-sync. Voor live synchronisatie kan later Supabase/Firebase worden toegevoegd.
