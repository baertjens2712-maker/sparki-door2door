Sparki Door2Door v4.1 — dashboard navigation fix

# Sparki Door2Door v4

Android MVP voor deur-aan-deur sales.

## v4
- Zwarte tekst op alle actieknoppen voor beter contrast.
- Map Focus als hoofdscherm.
- Dashboard met KPI's, historische kaart en volledige straatgeschiedenis.
- Straatgeschiedenis toont gemeente, nummerbereik, zijde, advisor, laatste wijziging, resultaten en afspraken.
- Tabblad Afspraken met datum/uur, Maps, Agenda en wijzigen.
- Team-backup export/import met merge op nieuwste huisnummerwijziging.
- CSV export.

De app gebruikt OpenStreetMap via osmdroid.
