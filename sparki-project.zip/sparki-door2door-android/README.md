# Sparki Door2Door – Android MVP

Een eenvoudige offline Android-app voor deur-aan-deur sales.

## Wat zit erin?

- Nieuwe straat starten met gemeente, straatnaam en huisnummerbereik.
- Kies **oneven**, **even** of **alle** huisnummers.
- De app genereert automatisch de reeks (bv. 1, 3, 5, 7...).
- Per huisnummer één tik op:
  - Niet thuis
  - Geen interesse
  - Interesse
  - Afspraak gemaakt
  - Contract / klant
  - Later teruggaan
- Na een status gaat de app automatisch naar de volgende nog niet bezochte deur.
- Vrije notitie per huisnummer.
- Straatsamenvatting en geschiedenis.
- CSV-export van alle bezochte adressen/resultaten.
- Alles wordt lokaal op het Android-toestel bewaard.

## Openen in Android Studio

1. Installeer Android Studio.
2. Pak de ZIP uit.
3. Kies **Open** en selecteer de map `sparki-door2door-android`.
4. Laat Android Studio de Gradle/SDK-componenten downloaden als daarom wordt gevraagd.
5. Sluit een Android-toestel aan of gebruik een emulator.
6. Klik op **Run**.

## Belangrijk voor samenwerken

Versie 1 is **offline en toestelgebonden**. Er is wel een `Sales advisor`-veld en CSV-export, maar nog geen live synchronisatie tussen twee telefoons.

Voor versie 2 kan Firebase/Supabase-sync worden toegevoegd, zodat twee advisors tegelijk dezelfde straten en huisnummers zien en dubbele bezoeken worden voorkomen.
