# Sparki Door2Door v3 — Map Focus

Android field-sales MVP voor deur-aan-deurverkoop.

## v3
- Kaart als hoofdscherm (OpenStreetMap)
- Automatische geocoding van straat en huisnummers via Android Geocoder
- Gekleurde huisnummermarkers per status
- Tik op marker → snelle statuskaart
- Kaart / lijst wisselen
- Oneven / even / alle huisnummers
- Direct afspraakdatum + uur vastleggen
- Centrale afsprakenlijst
- Open adres in Google Maps en voeg afspraak toe aan Android-agenda
- Overzicht met deuren, interesse, afspraken en klanten
- Team-backup export/import met merge op nieuwste wijziging
- v1/v2-data blijft leesbaar

## Statuskleuren
- Groen: klant
- Blauw: afspraak
- Geel: interesse
- Rood: niet thuis
- Donkergrijs: geen interesse
- Paars/grijs: later terug
- Lichtgrijs: niet bezocht

De kaart gebruikt OpenStreetMap-kaarttegels via osmdroid. Adresposities worden lokaal gecachet zodra Android Geocoder ze vindt.
