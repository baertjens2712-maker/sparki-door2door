package be.sparki.doortodoor;

import org.json.JSONException;
import org.json.JSONObject;

public class HouseVisit {
    public int number;
    public String status;
    public String note;
    public long updatedAt;
    public long appointmentAt;
    public double latitude;
    public double longitude;

    public HouseVisit(int number) {
        this.number = number;
        this.status = MainActivity.STATUS_NONE;
        this.note = "";
        this.updatedAt = 0L;
        this.appointmentAt = 0L;
        this.latitude = 0d;
        this.longitude = 0d;
    }

    public boolean hasLocation() {
        return Math.abs(latitude) > 0.000001 && Math.abs(longitude) > 0.000001;
    }

    public JSONObject toJson() throws JSONException {
        JSONObject obj = new JSONObject();
        obj.put("number", number);
        obj.put("status", status);
        obj.put("note", note);
        obj.put("updatedAt", updatedAt);
        obj.put("appointmentAt", appointmentAt);
        obj.put("latitude", latitude);
        obj.put("longitude", longitude);
        return obj;
    }

    public static HouseVisit fromJson(JSONObject obj) {
        HouseVisit h = new HouseVisit(obj.optInt("number", 0));
        h.status = obj.optString("status", MainActivity.STATUS_NONE);
        h.note = obj.optString("note", "");
        h.updatedAt = obj.optLong("updatedAt", 0L);
        h.appointmentAt = obj.optLong("appointmentAt", 0L);
        h.latitude = obj.optDouble("latitude", 0d);
        h.longitude = obj.optDouble("longitude", 0d);
        return h;
    }
}
