package be.sparki.doortodoor;

import org.json.JSONException;
import org.json.JSONObject;

public class HouseVisit {
    public int number;
    public String status;
    public String note;
    public long updatedAt;

    public HouseVisit(int number) {
        this.number = number;
        this.status = MainActivity.STATUS_NONE;
        this.note = "";
        this.updatedAt = 0L;
    }

    public JSONObject toJson() throws JSONException {
        JSONObject obj = new JSONObject();
        obj.put("number", number);
        obj.put("status", status);
        obj.put("note", note);
        obj.put("updatedAt", updatedAt);
        return obj;
    }

    public static HouseVisit fromJson(JSONObject obj) {
        HouseVisit h = new HouseVisit(obj.optInt("number", 0));
        h.status = obj.optString("status", MainActivity.STATUS_NONE);
        h.note = obj.optString("note", "");
        h.updatedAt = obj.optLong("updatedAt", 0L);
        return h;
    }
}
