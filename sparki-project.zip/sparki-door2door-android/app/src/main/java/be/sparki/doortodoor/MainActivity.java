package be.sparki.doortodoor;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.GradientDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.net.Uri;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.osmdroid.config.Configuration;
import org.osmdroid.tileprovider.tilesource.TileSourceFactory;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.util.BoundingBox;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.Marker;
import org.osmdroid.views.overlay.Polyline;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    public static final String STATUS_NONE = "Niet bezocht";
    public static final String STATUS_NOT_HOME = "Niet thuis";
    public static final String STATUS_NO_INTEREST = "Geen interesse";
    public static final String STATUS_INTEREST = "Interesse";
    public static final String STATUS_APPOINTMENT = "Afspraak gemaakt";
    public static final String STATUS_CUSTOMER = "Contract / klant";
    public static final String STATUS_LATER = "Later teruggaan";

    public static final String SIDE_ODD = "Oneven";
    public static final String SIDE_EVEN = "Even";
    public static final String SIDE_ALL = "Alles";

    private static final int EXPORT_REQUEST = 9001;
    private static final int TEAM_EXPORT_REQUEST = 9002;
    private static final int TEAM_IMPORT_REQUEST = 9003;

    private static final int BG = Color.rgb(247, 250, 248);
    private static final int CARD = Color.WHITE;
    private static final int TEXT = Color.rgb(25, 38, 33);
    private static final int MUTED = Color.rgb(102, 116, 109);
    private static final int GREEN = Color.rgb(15, 158, 77);
    private static final int GREEN_DARK = Color.rgb(8, 120, 57);
    private static final int BLUE = Color.rgb(37, 119, 222);
    private static final int YELLOW = Color.rgb(238, 169, 24);
    private static final int RED = Color.rgb(222, 65, 65);
    private static final int GRAY = Color.rgb(98, 108, 104);
    private static final int PURPLE = Color.rgb(112, 97, 174);
    private static final int BORDER = Color.rgb(225, 232, 228);
    private static final int LIGHT = Color.rgb(239, 244, 241);

    private Storage storage;
    private String currentScreen = "map";
    private String activeSessionId = null;
    private boolean listMode = false;
    private MapView mapView;
    private LinearLayout houseSheet;
    private TextView mapStatusText;
    private final ExecutorService geocodeExecutor = Executors.newSingleThreadExecutor();
    private boolean geocodeRunning = false;
    private String pendingCsv = null;
    private String pendingTeamJson = null;

    private static class AppointmentItem {
        StreetSession session;
        HouseVisit house;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        Configuration.getInstance().setUserAgentValue(getPackageName());
        Configuration.getInstance().load(this, getSharedPreferences("osmdroid", MODE_PRIVATE));
        storage = new Storage(this);
        List<StreetSession> sessions = storage.loadAll();
        if (!sessions.isEmpty()) activeSessionId = sessions.get(0).id;
        showMapHome();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mapView != null) mapView.onResume();
    }

    @Override
    protected void onPause() {
        if (mapView != null) mapView.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        geocodeExecutor.shutdownNow();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if ("map".equals(currentScreen)) super.onBackPressed();
        else showMapHome();
    }

    // ---------------------------------------------------------
    // MAP FOCUS HOME
    // ---------------------------------------------------------

    private void showMapHome() {
        currentScreen = "map";
        listMode = false;
        mapView = null;
        houseSheet = null;

        List<StreetSession> sessions = storage.loadAll();
        StreetSession s = resolveActiveSession(sessions);

        if (s == null) {
            LinearLayout root = baseScreen(false);
            addBrandHeader(root, "Kaart", "Start je eerste straat om huisnummers op de kaart te zien.");

            LinearLayout empty = card();
            TextView icon = titleText("📍"); icon.setTextSize(42); icon.setGravity(Gravity.CENTER); empty.addView(icon);
            TextView title = titleText("Je kaart is nog leeg"); title.setTextSize(22); title.setGravity(Gravity.CENTER); empty.addView(title);
            TextView text = smallText("Voeg een straat toe, kies oneven/even en de app maakt automatisch alle huisnummers. De kaartposities worden daarna gecachet.");
            text.setGravity(Gravity.CENTER); text.setPadding(dp(8), dp(10), dp(8), dp(16)); empty.addView(text);
            Button start = primaryButton("+ Nieuwe straat"); start.setOnClickListener(v -> showNewStreet()); empty.addView(start, fullButtonParams());
            root.addView(empty, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
            root.addView(bottomNav("map"));
            setContentView(root);
            return;
        }

        activeSessionId = s.id;
        LinearLayout root = baseScreen(false);
        addBrandHeader(root, s.street, streetSubtitle(s));

        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.HORIZONTAL);
        tools.setGravity(Gravity.CENTER_VERTICAL);
        Button streets = secondaryButton("☰ Straten"); streets.setOnClickListener(v -> showStreetPicker());
        Button add = primaryButton("+ Straat"); add.setOnClickListener(v -> showNewStreet());
        LinearLayout.LayoutParams p1 = new LinearLayout.LayoutParams(0, dp(46), 1f); p1.setMargins(0, 0, dp(6), 0);
        LinearLayout.LayoutParams p2 = new LinearLayout.LayoutParams(0, dp(46), 1f); p2.setMargins(dp(6), 0, 0, 0);
        tools.addView(streets, p1); tools.addView(add, p2);
        root.addView(tools);

        root.addView(progressStrip(s));

        LinearLayout tabs = segmentedControl();
        Button mapTab = segmentButton("Kaart", true);
        Button listTab = segmentButton("Lijst", false);
        tabs.addView(mapTab, weightNoMargin()); tabs.addView(listTab, weightNoMargin());
        root.addView(tabs);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        cp.topMargin = dp(8); root.addView(content, cp);

        mapTab.setOnClickListener(v -> {
            if (listMode) { listMode = false; showMapHome(); }
        });
        listTab.setOnClickListener(v -> showSessionList(s.id));

        buildMapContent(content, s);
        root.addView(bottomNav("map"));
        setContentView(root);
    }

    private StreetSession resolveActiveSession(List<StreetSession> sessions) {
        if (sessions.isEmpty()) return null;
        if (activeSessionId != null) {
            for (StreetSession s : sessions) if (activeSessionId.equals(s.id)) return s;
        }
        return sessions.get(0);
    }

    private void buildMapContent(LinearLayout content, StreetSession s) {
        mapStatusText = smallText(geocodeStatus(s));
        mapStatusText.setPadding(dp(4), dp(2), dp(4), dp(6));
        content.addView(mapStatusText);

        mapView = new MapView(this);
        mapView.setTileSource(TileSourceFactory.MAPNIK);
        mapView.setMultiTouchControls(true);
        mapView.setBuiltInZoomControls(false);
        mapView.getController().setZoom(18.0);

        GeoPoint initial = initialCenter(s);
        mapView.getController().setCenter(initial);

        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        mp.weight = 1f;
        mapView.setBackgroundColor(LIGHT);
        content.addView(mapView, mp);

        TextView attribution = smallText("© OpenStreetMap contributors");
        attribution.setTextSize(10); attribution.setGravity(Gravity.RIGHT); attribution.setPadding(0, dp(2), dp(2), dp(3));
        content.addView(attribution);

        houseSheet = new LinearLayout(this);
        houseSheet.setOrientation(LinearLayout.VERTICAL);
        houseSheet.setPadding(dp(12), dp(10), dp(12), dp(10));
        houseSheet.setBackground(roundRect(CARD, BORDER, 18));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sp.setMargins(0, dp(4), 0, dp(4));
        content.addView(houseSheet, sp);

        refreshMapMarkers(s);
        HouseVisit selected = selectedHouse(s);
        showHouseSheet(s, selected);
        geocodeSession(s);
    }

    private GeoPoint initialCenter(StreetSession s) {
        if (Math.abs(s.mapCenterLat) > 0.000001 && Math.abs(s.mapCenterLon) > 0.000001) {
            return new GeoPoint(s.mapCenterLat, s.mapCenterLon);
        }
        for (HouseVisit h : s.houses) if (h.hasLocation()) return new GeoPoint(h.latitude, h.longitude);
        return new GeoPoint(50.8503, 4.3517);
    }

    private void refreshMapMarkers(StreetSession s) {
        if (mapView == null) return;
        mapView.getOverlays().clear();
        for (HouseVisit h : s.houses) {
            if (!h.hasLocation()) continue;
            Marker marker = new Marker(mapView);
            marker.setPosition(new GeoPoint(h.latitude, h.longitude));
            marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
            marker.setIcon(markerDrawable(h.number, colorForStatus(h.status)));
            marker.setTitle(s.street + " " + h.number);
            marker.setSnippet(h.status);
            marker.setOnMarkerClickListener((m, mv) -> {
                int index = indexOfHouse(s, h.number);
                if (index >= 0) {
                    s.currentIndex = index;
                    s.updatedAt = System.currentTimeMillis();
                    storage.save(s);
                }
                showHouseSheet(s, h);
                mv.getController().animateTo(m.getPosition());
                return true;
            });
            mapView.getOverlays().add(marker);
        }
        mapView.invalidate();
    }

    private BitmapDrawable markerDrawable(int number, int fillColor) {
        int size = dp(46);
        Bitmap bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(bitmap);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        paint.setColor(fillColor);
        canvas.drawCircle(size / 2f, size / 2f, size * 0.43f, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(2));
        paint.setColor(Color.WHITE);
        canvas.drawCircle(size / 2f, size / 2f, size * 0.43f, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.WHITE);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(Typeface.DEFAULT_BOLD);
        paint.setTextSize(number >= 100 ? dp(12) : dp(14));
        Paint.FontMetrics fm = paint.getFontMetrics();
        float y = size / 2f - (fm.ascent + fm.descent) / 2f;
        canvas.drawText(String.valueOf(number), size / 2f, y, paint);
        return new BitmapDrawable(getResources(), bitmap);
    }

    private void showHouseSheet(StreetSession s, HouseVisit house) {
        if (houseSheet == null || house == null) return;
        houseSheet.removeAllViews();

        LinearLayout head = new LinearLayout(this); head.setOrientation(LinearLayout.HORIZONTAL); head.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout info = new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL);
        TextView address = titleText(s.street + " " + house.number); address.setTextSize(19); info.addView(address);
        TextView status = smallText(house.status + (house.appointmentAt > 0 ? "  •  " + formatDateTime(house.appointmentAt) : ""));
        status.setTextColor(colorForStatus(house.status)); info.addView(status);
        head.addView(info, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Button maps = compactButton("Maps", Color.WHITE, GREEN_DARK, BORDER);
        maps.setOnClickListener(v -> openInMaps(s, house));
        head.addView(maps, new LinearLayout.LayoutParams(dp(78), dp(40)));
        houseSheet.addView(head);

        LinearLayout r1 = statusRow();
        Button customer = quickStatus("✓ Klant", GREEN); customer.setOnClickListener(v -> markAndAdvance(s, house, STATUS_CUSTOMER));
        Button appointment = quickStatus("▣ Afspraak", BLUE); appointment.setOnClickListener(v -> pickAppointment(s, house));
        Button interest = quickStatus("★ Interesse", YELLOW); interest.setOnClickListener(v -> markAndAdvance(s, house, STATUS_INTEREST));
        r1.addView(customer, weightCompact()); r1.addView(appointment, weightCompact()); r1.addView(interest, weightCompact());
        houseSheet.addView(r1);

        LinearLayout r2 = statusRow();
        Button notHome = quickStatus("⌂ Niet thuis", RED); notHome.setOnClickListener(v -> markAndAdvance(s, house, STATUS_NOT_HOME));
        Button no = quickStatus("× Geen interesse", GRAY); no.setOnClickListener(v -> markAndAdvance(s, house, STATUS_NO_INTEREST));
        Button later = quickStatus("◷ Later", PURPLE); later.setOnClickListener(v -> markAndAdvance(s, house, STATUS_LATER));
        r2.addView(notHome, weightCompact()); r2.addView(no, weightCompact()); r2.addView(later, weightCompact());
        houseSheet.addView(r2);

        LinearLayout noteRow = new LinearLayout(this); noteRow.setOrientation(LinearLayout.HORIZONTAL); noteRow.setGravity(Gravity.CENTER_VERTICAL);
        EditText note = field("Notitie", "Korte notitie…"); note.setText(house.note == null ? "" : house.note); note.setSingleLine(true);
        noteRow.addView(note, new LinearLayout.LayoutParams(0, dp(44), 1f));
        Button save = compactButton("Opslaan", GREEN, Color.WHITE, GREEN);
        save.setOnClickListener(v -> {
            house.note = note.getText().toString().trim();
            house.updatedAt = System.currentTimeMillis(); s.updatedAt = house.updatedAt; storage.save(s);
            Toast.makeText(this, "Notitie opgeslagen", Toast.LENGTH_SHORT).show();
        });
        LinearLayout.LayoutParams svp = new LinearLayout.LayoutParams(dp(92), dp(44)); svp.leftMargin = dp(8); noteRow.addView(save, svp);
        noteRow.setPadding(0, dp(5), 0, 0);
        houseSheet.addView(noteRow);
    }

    private void markAndAdvance(StreetSession s, HouseVisit house, String status) {
        house.status = status;
        if (!STATUS_APPOINTMENT.equals(status)) house.appointmentAt = 0L;
        house.updatedAt = System.currentTimeMillis(); s.updatedAt = house.updatedAt;
        int current = indexOfHouse(s, house.number);
        int next = findNextUnvisited(s, current + 1);
        if (next < 0) next = findNextUnvisited(s, 0);
        if (next >= 0) s.currentIndex = next;
        storage.save(s);
        refreshMapMarkers(s);
        updateMapStatus(s);
        HouseVisit nextHouse = selectedHouse(s);
        showHouseSheet(s, nextHouse);
        if (nextHouse != null && nextHouse.hasLocation() && mapView != null) mapView.getController().animateTo(new GeoPoint(nextHouse.latitude, nextHouse.longitude));
    }

    private void pickAppointment(StreetSession s, HouseVisit house) {
        Calendar c = Calendar.getInstance();
        if (house.appointmentAt > 0) c.setTimeInMillis(house.appointmentAt);
        else c.add(Calendar.DAY_OF_MONTH, 1);
        DatePickerDialog dpd = new DatePickerDialog(this, (view, year, month, day) -> {
            Calendar chosen = Calendar.getInstance();
            chosen.set(Calendar.YEAR, year); chosen.set(Calendar.MONTH, month); chosen.set(Calendar.DAY_OF_MONTH, day);
            TimePickerDialog tpd = new TimePickerDialog(this, (timeView, hour, minute) -> {
                chosen.set(Calendar.HOUR_OF_DAY, hour); chosen.set(Calendar.MINUTE, minute); chosen.set(Calendar.SECOND, 0); chosen.set(Calendar.MILLISECOND, 0);
                house.appointmentAt = chosen.getTimeInMillis();
                house.status = STATUS_APPOINTMENT;
                house.updatedAt = System.currentTimeMillis(); s.updatedAt = house.updatedAt;
                storage.save(s);
                refreshMapMarkers(s); updateMapStatus(s); showHouseSheet(s, house);
                Toast.makeText(this, "Afspraak: " + formatDateTime(house.appointmentAt), Toast.LENGTH_LONG).show();
            }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true);
            tpd.setTitle("Uur van afspraak"); tpd.show();
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
        dpd.setTitle("Datum van afspraak"); dpd.show();
    }

    private void updateMapStatus(StreetSession s) {
        if (mapStatusText != null) mapStatusText.setText(geocodeStatus(s));
    }

    private String geocodeStatus(StreetSession s) {
        int located = s.locatedCount();
        String mapPart = located == s.houses.size() ? "Alle huisnummers op kaart" : located + "/" + s.houses.size() + " huisnummers op kaart";
        return s.visitedCount() + "/" + s.houses.size() + " bezocht  •  " + mapPart;
    }

    private void geocodeSession(StreetSession original) {
        if (geocodeRunning || original == null) return;
        boolean needsCenter = Math.abs(original.mapCenterLat) < 0.000001;
        boolean needsHouses = original.locatedCount() < original.houses.size();
        if (!needsCenter && !needsHouses) return;
        geocodeRunning = true;
        final String sessionId = original.id;

        geocodeExecutor.submit(() -> {
            StreetSession s = storage.find(sessionId);
            if (s == null) { geocodeRunning = false; return; }
            try {
                Geocoder geocoder = new Geocoder(this, new Locale("nl", "BE"));
                if (Math.abs(s.mapCenterLat) < 0.000001) {
                    Address a = geocodeOne(geocoder, s.street + ", " + s.municipality + ", België");
                    if (a != null) {
                        s.mapCenterLat = a.getLatitude(); s.mapCenterLon = a.getLongitude(); storage.save(s);
                        runOnUiThread(() -> {
                            if ("map".equals(currentScreen) && sessionId.equals(activeSessionId) && mapView != null) {
                                mapView.getController().setCenter(new GeoPoint(s.mapCenterLat, s.mapCenterLon));
                                mapView.getController().setZoom(18.0);
                            }
                        });
                    }
                }

                int processed = 0;
                for (HouseVisit h : s.houses) {
                    if (Thread.currentThread().isInterrupted()) break;
                    if (h.hasLocation()) continue;
                    Address a = geocodeOne(geocoder, s.street + " " + h.number + ", " + s.municipality + ", België");
                    if (a != null) {
                        h.latitude = a.getLatitude(); h.longitude = a.getLongitude();
                    }
                    processed++;
                    if (processed % 4 == 0 || a != null) storage.save(s);
                    if (a != null) {
                        runOnUiThread(() -> {
                            if ("map".equals(currentScreen) && sessionId.equals(activeSessionId)) {
                                StreetSession latest = storage.find(sessionId);
                                if (latest != null) { refreshMapMarkers(latest); updateMapStatus(latest); }
                            }
                        });
                    }
                    try { Thread.sleep(180); } catch (InterruptedException e) { Thread.currentThread().interrupt(); break; }
                }
                storage.save(s);
            } catch (Exception ignored) { }
            geocodeRunning = false;
            runOnUiThread(() -> {
                if ("map".equals(currentScreen) && sessionId.equals(activeSessionId)) {
                    StreetSession latest = storage.find(sessionId);
                    if (latest != null) { refreshMapMarkers(latest); updateMapStatus(latest); }
                }
            });
        });
    }

    @SuppressWarnings("deprecation")
    private Address geocodeOne(Geocoder geocoder, String query) {
        try {
            List<Address> list = geocoder.getFromLocationName(query, 1);
            if (list != null && !list.isEmpty()) return list.get(0);
        } catch (Exception ignored) { }
        return null;
    }

    // ---------------------------------------------------------
    // LIST MODE
    // ---------------------------------------------------------

    private void showSessionList(String id) {
        currentScreen = "map";
        listMode = true;
        mapView = null;
        StreetSession s = storage.find(id);
        if (s == null) { showMapHome(); return; }
        activeSessionId = id;

        LinearLayout root = baseScreen(false);
        addBrandHeader(root, s.street, streetSubtitle(s));
        root.addView(progressStrip(s));

        LinearLayout tabs = segmentedControl();
        Button mapTab = segmentButton("Kaart", false); mapTab.setOnClickListener(v -> showMapHome());
        Button listTab = segmentButton("Lijst", true);
        tabs.addView(mapTab, weightNoMargin()); tabs.addView(listTab, weightNoMargin()); root.addView(tabs);

        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(0, dp(8), 0, dp(8));
        for (HouseVisit h : s.houses) {
            LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(12), dp(8), dp(10), dp(8)); row.setBackground(roundRect(CARD, BORDER, 13));
            LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(62)); rp.setMargins(0, dp(3), 0, dp(3)); row.setLayoutParams(rp);
            TextView num = titleText(String.valueOf(h.number)); num.setTextSize(18); num.setGravity(Gravity.CENTER); num.setBackground(roundRect(colorForStatus(h.status), colorForStatus(h.status), 20)); num.setTextColor(Color.WHITE);
            row.addView(num, new LinearLayout.LayoutParams(dp(44), dp(44)));
            LinearLayout info = new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL); info.setPadding(dp(12), 0, 0, 0);
            TextView st = titleText(h.status); st.setTextSize(15); info.addView(st);
            String sub = h.appointmentAt > 0 ? formatDateTime(h.appointmentAt) : (isBlank(h.note) ? "Tik om te openen" : h.note);
            info.addView(smallText(sub)); row.addView(info, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            TextView arrow = titleText("›"); arrow.setTextSize(28); arrow.setTextColor(MUTED); row.addView(arrow);
            row.setOnClickListener(v -> {
                int index = indexOfHouse(s, h.number); if (index >= 0) s.currentIndex = index; storage.save(s); listMode = false; showMapHome();
            });
            list.addView(row);
        }
        ScrollView scroll = new ScrollView(this); scroll.addView(list); root.addView(scroll, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(bottomNav("map"));
        setContentView(root);
    }

    // ---------------------------------------------------------
    // NEW STREET + PICKER
    // ---------------------------------------------------------

    private void showNewStreet() {
        currentScreen = "new";
        LinearLayout root = baseScreen(true);
        addSimpleHeader(root, "Nieuwe straat", "De app maakt automatisch de juiste huisnummers en probeert ze op de kaart te plaatsen.", true);

        EditText advisor = field("Sales advisor", "Bijv. Jens");
        EditText municipality = field("Gemeente", "Bijv. Lede");
        EditText street = field("Straatnaam", "Bijv. Stationsstraat");
        EditText from = numberField("Van huisnummer", "1");
        EditText to = numberField("Tot huisnummer", "99");
        root.addView(labeled("Sales advisor", advisor)); root.addView(labeled("Gemeente", municipality)); root.addView(labeled("Straatnaam", street));

        LinearLayout nums = new LinearLayout(this); nums.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout left = new LinearLayout(this); left.setOrientation(LinearLayout.VERTICAL); left.addView(label("Van nummer")); left.addView(from);
        LinearLayout right = new LinearLayout(this); right.setOrientation(LinearLayout.VERTICAL); right.addView(label("Tot nummer")); right.addView(to);
        nums.addView(left, weightParams()); nums.addView(right, weightParams()); root.addView(nums);

        root.addView(label("Welke kant doe je?"));
        RadioGroup group = new RadioGroup(this); group.setOrientation(RadioGroup.HORIZONTAL);
        RadioButton odd = radio("Oneven"); odd.setId(View.generateViewId()); odd.setChecked(true);
        RadioButton even = radio("Even"); even.setId(View.generateViewId());
        RadioButton all = radio("Alles"); all.setId(View.generateViewId());
        group.addView(odd, weightParams()); group.addView(even, weightParams()); group.addView(all, weightParams()); root.addView(group);

        Button start = primaryButton("Start op de kaart");
        start.setOnClickListener(v -> {
            String streetText = street.getText().toString().trim();
            String municipalityText = municipality.getText().toString().trim();
            if (streetText.isEmpty()) { street.setError("Vul een straatnaam in"); return; }
            if (municipalityText.isEmpty()) { municipality.setError("Vul een gemeente in"); return; }
            int a, b;
            try { a = Integer.parseInt(from.getText().toString().trim()); b = Integer.parseInt(to.getText().toString().trim()); }
            catch (Exception e) { Toast.makeText(this, "Vul geldige huisnummers in", Toast.LENGTH_SHORT).show(); return; }
            if (a > b) { int t = a; a = b; b = t; }
            String side = odd.isChecked() ? SIDE_ODD : even.isChecked() ? SIDE_EVEN : SIDE_ALL;
            StreetSession s = new StreetSession();
            s.id = UUID.randomUUID().toString(); s.advisor = advisor.getText().toString().trim(); s.municipality = municipalityText; s.street = streetText;
            s.startNumber = a; s.endNumber = b; s.side = side; s.createdAt = System.currentTimeMillis(); s.updatedAt = s.createdAt; s.currentIndex = 0;
            for (int n = a; n <= b; n++) if (SIDE_ALL.equals(side) || (SIDE_ODD.equals(side) && n % 2 != 0) || (SIDE_EVEN.equals(side) && n % 2 == 0)) s.houses.add(new HouseVisit(n));
            if (s.houses.isEmpty()) { Toast.makeText(this, "Geen huisnummers in dit bereik", Toast.LENGTH_SHORT).show(); return; }
            storage.save(s); activeSessionId = s.id; showMapHome();
        });
        root.addView(start, fullButtonParams());
        setContentView(wrapInScroll(root));
    }

    private void showStreetPicker() {
        List<StreetSession> sessions = storage.loadAll();
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(12), dp(8), dp(12), dp(8));
        for (StreetSession s : sessions) {
            Button b = secondaryButton(s.street + "  •  " + s.municipality + "  •  " + s.visitedCount() + "/" + s.houses.size());
            b.setOnClickListener(v -> { activeSessionId = s.id; showMapHome(); }); box.addView(b, fullButtonParams());
        }
        Button add = primaryButton("+ Nieuwe straat"); add.setOnClickListener(v -> showNewStreet()); box.addView(add, fullButtonParams());
        ScrollView sv = new ScrollView(this); sv.addView(box);
        new AlertDialog.Builder(this).setTitle("Kies een straat").setView(sv).setNegativeButton("Sluiten", null).show();
    }

    // ---------------------------------------------------------
    // APPOINTMENTS
    // ---------------------------------------------------------

    private void showAppointments() {
        currentScreen = "appointments";
        List<AppointmentItem> items = appointmentItems();
        LinearLayout root = baseScreen(false);
        addBrandHeader(root, "Afspraken", items.isEmpty() ? "Nog geen afspraken gepland" : items.size() + " geplande afspraken");

        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL); list.setPadding(0, dp(8), 0, dp(10));
        if (items.isEmpty()) {
            LinearLayout empty = card(); empty.addView(titleText("Geen afspraken")); empty.addView(smallText("Tik bij een huisnummer op ‘Afspraak’ om meteen datum en uur vast te leggen.")); list.addView(empty);
        } else {
            for (AppointmentItem item : items) list.addView(appointmentCard(item));
        }
        ScrollView sv = new ScrollView(this); sv.addView(list); root.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(bottomNav("appointments")); setContentView(root);
    }

    private List<AppointmentItem> appointmentItems() {
        List<AppointmentItem> out = new ArrayList<>();
        for (StreetSession s : storage.loadAll()) for (HouseVisit h : s.houses) if (h.appointmentAt > 0) { AppointmentItem i = new AppointmentItem(); i.session = s; i.house = h; out.add(i); }
        out.sort(Comparator.comparingLong(a -> a.house.appointmentAt)); return out;
    }

    private LinearLayout appointmentCard(AppointmentItem item) {
        LinearLayout c = card();
        TextView when = titleText(formatDateTime(item.house.appointmentAt)); when.setTextSize(18); when.setTextColor(BLUE); c.addView(when);
        TextView address = titleText(item.session.street + " " + item.house.number + " • " + item.session.municipality); address.setTextSize(16); address.setPadding(0, dp(4), 0, dp(3)); c.addView(address);
        if (!isBlank(item.session.advisor)) c.addView(smallText("Advisor: " + item.session.advisor));
        if (!isBlank(item.house.note)) c.addView(smallText(item.house.note));
        LinearLayout row = statusRow();
        Button maps = compactButton("Maps", Color.WHITE, GREEN_DARK, BORDER); maps.setOnClickListener(v -> openInMaps(item.session, item.house));
        Button cal = compactButton("Agenda", Color.WHITE, BLUE, BORDER); cal.setOnClickListener(v -> addToCalendar(item.session, item.house));
        Button edit = compactButton("Wijzig", Color.WHITE, TEXT, BORDER); edit.setOnClickListener(v -> pickAppointment(item.session, item.house));
        row.addView(maps, weightCompact()); row.addView(cal, weightCompact()); row.addView(edit, weightCompact()); c.addView(row);
        c.setOnClickListener(v -> { activeSessionId = item.session.id; int idx = indexOfHouse(item.session, item.house.number); if (idx >= 0) { item.session.currentIndex = idx; storage.save(item.session); } showMapHome(); });
        return c;
    }

    private void openInMaps(StreetSession s, HouseVisit h) {
        String q = Uri.encode(s.street + " " + h.number + ", " + s.municipality + ", België");
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + q));
        try { startActivity(intent); } catch (Exception e) { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=" + q))); }
    }

    private void addToCalendar(StreetSession s, HouseVisit h) {
        if (h.appointmentAt <= 0) return;
        Intent intent = new Intent(Intent.ACTION_INSERT).setData(CalendarContract.Events.CONTENT_URI)
                .putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, h.appointmentAt)
                .putExtra(CalendarContract.EXTRA_EVENT_END_TIME, h.appointmentAt + 45 * 60 * 1000L)
                .putExtra(CalendarContract.Events.TITLE, "Sparki afspraak – " + s.street + " " + h.number)
                .putExtra(CalendarContract.Events.EVENT_LOCATION, s.street + " " + h.number + ", " + s.municipality)
                .putExtra(CalendarContract.Events.DESCRIPTION, h.note == null ? "" : h.note);
        try { startActivity(intent); } catch (Exception e) { Toast.makeText(this, "Geen agenda-app gevonden", Toast.LENGTH_SHORT).show(); }
    }

    // ---------------------------------------------------------
    // OVERVIEW
    // ---------------------------------------------------------

    private void showDashboard() {
        currentScreen = "dashboard";
        List<StreetSession> sessions = storage.loadAll();
        int visited = 0, interest = 0, appointments = 0, customers = 0, notHome = 0, later = 0;
        for (StreetSession s : sessions) {
            visited += s.visitedCount();
            interest += s.countStatus(STATUS_INTEREST);
            customers += s.countStatus(STATUS_CUSTOMER);
            notHome += s.countStatus(STATUS_NOT_HOME);
            later += s.countStatus(STATUS_LATER);
            for (HouseVisit h : s.houses) if (h.appointmentAt > 0) appointments++;
        }

        LinearLayout root = baseScreen(false);
        addBrandHeader(root, "Dashboard", "Kaart, resultaten en volledige straatgeschiedenis");

        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(0, 0, 0, dp(10));

        LinearLayout r1 = new LinearLayout(this); r1.setOrientation(LinearLayout.HORIZONTAL);
        r1.addView(statCard("Bezocht", String.valueOf(visited)), weightParams());
        r1.addView(statCard("Interesse", String.valueOf(interest)), weightParams());
        body.addView(r1);
        LinearLayout r2 = new LinearLayout(this); r2.setOrientation(LinearLayout.HORIZONTAL);
        r2.addView(statCard("Afspraken", String.valueOf(appointments)), weightParams());
        r2.addView(statCard("Klanten", String.valueOf(customers)), weightParams());
        body.addView(r2);
        LinearLayout r3 = new LinearLayout(this); r3.setOrientation(LinearLayout.HORIZONTAL);
        r3.addView(statCard("Niet thuis", String.valueOf(notHome)), weightParams());
        String conv = visited == 0 ? "0%" : Math.round((customers * 100f) / visited) + "%";
        r3.addView(statCard("Conversie", conv), weightParams());
        body.addView(r3);

        LinearLayout mapCard = card();
        TextView mapTitle = titleText("Historiek op kaart"); mapTitle.setTextSize(18); mapCard.addView(mapTitle);
        TextView mapSub = smallText("Alle eerder gebruikte straten en huisnummers op één kaart. Kleuren tonen de laatste status per huisnummer.");
        mapSub.setPadding(0, dp(4), 0, dp(8)); mapCard.addView(mapSub);

        MapView historyMap = new MapView(this);
        mapView = historyMap;
        historyMap.setTileSource(TileSourceFactory.MAPNIK);
        historyMap.setMultiTouchControls(true);
        historyMap.setBuiltInZoomControls(false);
        historyMap.setBackgroundColor(LIGHT);
        mapCard.addView(historyMap, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(300)));
        body.addView(mapCard);
        populateHistoryMap(historyMap, sessions);

        LinearLayout historyHeader = new LinearLayout(this);
        historyHeader.setOrientation(LinearLayout.HORIZONTAL); historyHeader.setGravity(Gravity.CENTER_VERTICAL);
        TextView historyTitle = titleText("Straatgeschiedenis"); historyTitle.setTextSize(20);
        TextView count = smallText(sessions.size() + (sessions.size() == 1 ? " straat" : " straten")); count.setGravity(Gravity.RIGHT);
        historyHeader.addView(historyTitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        historyHeader.addView(count);
        historyHeader.setPadding(dp(2), dp(10), dp(2), dp(4)); body.addView(historyHeader);

        if (sessions.isEmpty()) {
            LinearLayout empty = card(); empty.addView(titleText("Nog geen geschiedenis"));
            empty.addView(smallText("Zodra je een straat start, verschijnt die hier automatisch met alle resultaten en bezochte huisnummers."));
            body.addView(empty);
        } else {
            for (StreetSession s : sessions) body.addView(historyCard(s));
        }

        Button csv = secondaryButton("Exporteer volledige geschiedenis naar CSV");
        csv.setOnClickListener(v -> exportCsv()); body.addView(csv, fullButtonParams());
        TextView hint = smallText("Team-tip: deel een backup via ‘Team’. De nieuwste status per huisnummer wordt bij import behouden.");
        hint.setPadding(dp(4), dp(8), dp(4), dp(12)); body.addView(hint);

        ScrollView sv = new ScrollView(this); sv.addView(body);
        root.addView(sv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        root.addView(bottomNav("dashboard"));
        setContentView(root);
    }

    private void populateHistoryMap(MapView historyMap, List<StreetSession> sessions) {
        List<GeoPoint> allPoints = new ArrayList<>();
        historyMap.getOverlays().clear();

        for (StreetSession s : sessions) {
            List<GeoPoint> streetPoints = new ArrayList<>();
            List<HouseVisit> ordered = new ArrayList<>(s.houses);
            ordered.sort(Comparator.comparingInt(h -> h.number));

            for (HouseVisit h : ordered) {
                if (!h.hasLocation()) continue;
                GeoPoint point = new GeoPoint(h.latitude, h.longitude);
                allPoints.add(point);
                streetPoints.add(point);

                Marker marker = new Marker(historyMap);
                marker.setPosition(point);
                marker.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);
                marker.setIcon(markerDrawable(h.number, colorForStatus(h.status)));
                marker.setTitle(s.street + " " + h.number);
                marker.setSnippet(h.status + (h.appointmentAt > 0 ? " • " + formatDateTime(h.appointmentAt) : ""));
                marker.setOnMarkerClickListener((m, mv) -> { m.showInfoWindow(); return true; });
                historyMap.getOverlays().add(marker);
            }

            if (streetPoints.size() >= 2) {
                Polyline line = new Polyline(historyMap);
                line.setPoints(streetPoints);
                line.setWidth(7f);
                int pct = s.houses.isEmpty() ? 0 : Math.round(s.visitedCount() * 100f / s.houses.size());
                line.setColor(pct >= 100 ? GREEN_DARK : pct > 0 ? YELLOW : GRAY);
                line.setTitle(s.street + " • " + s.visitedCount() + "/" + s.houses.size());
                historyMap.getOverlays().add(line);
            }
        }

        if (allPoints.isEmpty()) {
            historyMap.getController().setZoom(9.5);
            historyMap.getController().setCenter(new GeoPoint(50.95, 3.85));
        } else if (allPoints.size() == 1) {
            historyMap.getController().setZoom(18.0);
            historyMap.getController().setCenter(allPoints.get(0));
        } else {
            BoundingBox box = BoundingBox.fromGeoPoints(allPoints);
            historyMap.post(() -> historyMap.zoomToBoundingBox(box, true, dp(45)));
        }
        historyMap.invalidate();
    }

    private LinearLayout historyCard(StreetSession s) {
        LinearLayout c = card();
        LinearLayout header = new LinearLayout(this); header.setOrientation(LinearLayout.HORIZONTAL); header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = titleText(s.street); title.setTextSize(18);
        TextView pct = smallText(s.houses.isEmpty() ? "0%" : Math.round(s.visitedCount() * 100f / s.houses.size()) + "%");
        pct.setTextColor(GREEN_DARK); pct.setTypeface(Typeface.DEFAULT_BOLD);
        header.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)); header.addView(pct); c.addView(header);

        c.addView(smallText(s.municipality + " • " + s.side + " • nr. " + s.startNumber + "–" + s.endNumber));
        String advisorLine = "Laatst bijgewerkt: " + formatDateTime(s.updatedAt);
        if (!isBlank(s.advisor)) advisorLine += " • " + s.advisor;
        TextView meta = smallText(advisorLine); meta.setPadding(0, dp(3), 0, dp(5)); c.addView(meta);

        TextView stats = smallText(
                s.visitedCount() + "/" + s.houses.size() + " bezocht" +
                "  •  " + s.countStatus(STATUS_INTEREST) + " interesse" +
                "  •  " + s.countStatus(STATUS_CUSTOMER) + " klant" +
                "  •  " + appointmentCount(s) + " afspraak");
        stats.setTextColor(TEXT); c.addView(stats);

        LinearLayout row = statusRow();
        Button open = compactButton("Bekijk straat", GREEN, Color.BLACK, GREEN_DARK);
        open.setOnClickListener(v -> { activeSessionId = s.id; showMapHome(); });
        Button maps = compactButton("Open Maps", Color.WHITE, Color.BLACK, BORDER);
        maps.setOnClickListener(v -> openStreetInMaps(s));
        row.addView(open, weightCompact()); row.addView(maps, weightCompact()); c.addView(row);
        return c;
    }

    private int appointmentCount(StreetSession s) {
        int n = 0; for (HouseVisit h : s.houses) if (h.appointmentAt > 0) n++; return n;
    }

    private void openStreetInMaps(StreetSession s) {
        String q = Uri.encode(s.street + ", " + s.municipality + ", België");
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + q));
        try { startActivity(intent); } catch (Exception e) { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=" + q))); }
    }

    // ---------------------------------------------------------
    // TEAM SHARE / MERGE
    // ---------------------------------------------------------

    private void showTeam() {
        currentScreen = "team";
        LinearLayout root = baseScreen(false); addBrandHeader(root, "Team", "Deel dezelfde straatdata met je collega");
        LinearLayout info = card(); info.addView(titleText("Samenwerken in v4"));
        TextView t = smallText("Exporteren maakt één team-backup. Je collega importeert die op zijn toestel. Bij samenvoegen wint automatisch de nieuwste wijziging per huisnummer. Dashboard, afspraken en straatgeschiedenis blijven zo op beide toestellen samenvoegbaar. Live cloud-sync kan als volgende stap worden toegevoegd."); t.setPadding(0, dp(8), 0, 0); info.addView(t); root.addView(info);
        Button export = primaryButton("↑ Team-backup exporteren"); export.setOnClickListener(v -> exportTeam()); root.addView(export, fullButtonParams());
        Button imp = secondaryButton("↓ Backup van collega importeren"); imp.setOnClickListener(v -> importTeam()); root.addView(imp, fullButtonParams());
        LinearLayout.LayoutParams spacer = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f); root.addView(new View(this), spacer);
        root.addView(bottomNav("team")); setContentView(root);
    }

    private void exportTeam() {
        pendingTeamJson = storage.exportJson();
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT); intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType("application/json"); intent.putExtra(Intent.EXTRA_TITLE, "sparki-team-backup.json");
        startActivityForResult(intent, TEAM_EXPORT_REQUEST);
    }

    private void importTeam() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT); intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType("*/*"); startActivityForResult(intent, TEAM_IMPORT_REQUEST);
    }

    private void exportCsv() {
        StringBuilder sb = new StringBuilder("Gemeente;Straat;Huisnummer;Advisor;Status;Afspraak;Notitie;Latitude;Longitude\n");
        for (StreetSession s : storage.loadAll()) for (HouseVisit h : s.houses) {
            sb.append(escapeCsv(s.municipality)).append(';').append(escapeCsv(s.street)).append(';').append(h.number).append(';')
                    .append(escapeCsv(s.advisor)).append(';').append(escapeCsv(h.status)).append(';')
                    .append(h.appointmentAt > 0 ? escapeCsv(formatDateTime(h.appointmentAt)) : "").append(';').append(escapeCsv(h.note)).append(';')
                    .append(h.latitude).append(';').append(h.longitude).append('\n');
        }
        pendingCsv = sb.toString();
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT); intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType("text/csv"); intent.putExtra(Intent.EXTRA_TITLE, "sparki-door2door.csv"); startActivityForResult(intent, EXPORT_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == EXPORT_REQUEST && pendingCsv != null) {
            if (writeText(uri, pendingCsv)) Toast.makeText(this, "CSV opgeslagen", Toast.LENGTH_SHORT).show(); pendingCsv = null;
        } else if (requestCode == TEAM_EXPORT_REQUEST && pendingTeamJson != null) {
            if (writeText(uri, pendingTeamJson)) Toast.makeText(this, "Team-backup opgeslagen", Toast.LENGTH_SHORT).show(); pendingTeamJson = null;
        } else if (requestCode == TEAM_IMPORT_REQUEST) {
            try {
                String raw = readText(uri); int changed = storage.mergeJson(raw);
                if (changed < 0) Toast.makeText(this, "Dit is geen geldige Sparki-backup", Toast.LENGTH_LONG).show();
                else { Toast.makeText(this, changed + " wijzigingen samengevoegd", Toast.LENGTH_LONG).show(); showTeam(); }
            } catch (Exception e) { Toast.makeText(this, "Importeren mislukt", Toast.LENGTH_LONG).show(); }
        }
    }

    private boolean writeText(Uri uri, String text) {
        try (OutputStream out = getContentResolver().openOutputStream(uri)) {
            if (out != null) { out.write(text.getBytes(StandardCharsets.UTF_8)); return true; }
        } catch (Exception e) { Toast.makeText(this, "Opslaan mislukt", Toast.LENGTH_SHORT).show(); }
        return false;
    }

    private String readText(Uri uri) throws Exception {
        try (InputStream in = getContentResolver().openInputStream(uri); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            if (in == null) return ""; byte[] buffer = new byte[8192]; int n; while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n); return out.toString(StandardCharsets.UTF_8.name());
        }
    }

    // ---------------------------------------------------------
    // HELPERS: DATA
    // ---------------------------------------------------------

    private HouseVisit selectedHouse(StreetSession s) {
        if (s == null || s.houses.isEmpty()) return null;
        if (s.currentIndex < 0 || s.currentIndex >= s.houses.size()) s.currentIndex = 0;
        return s.houses.get(s.currentIndex);
    }

    private int findNextUnvisited(StreetSession s, int start) {
        for (int i = Math.max(0, start); i < s.houses.size(); i++) if (STATUS_NONE.equals(s.houses.get(i).status)) return i;
        return -1;
    }

    private int indexOfHouse(StreetSession s, int number) {
        for (int i = 0; i < s.houses.size(); i++) if (s.houses.get(i).number == number) return i;
        return -1;
    }

    private String streetSubtitle(StreetSession s) {
        String pct = s.houses.isEmpty() ? "0%" : Math.round(s.visitedCount() * 100f / s.houses.size()) + "%";
        return s.municipality + "  •  " + s.side + "  •  " + pct + (isBlank(s.advisor) ? "" : "  •  " + s.advisor);
    }

    private String formatDateTime(long millis) { return new SimpleDateFormat("dd/MM/yyyy HH:mm", new Locale("nl", "BE")).format(new Date(millis)); }
    private boolean isBlank(String s) { return s == null || s.trim().isEmpty(); }
    private String escapeCsv(String value) { if (value == null) return ""; String v = value.replace("\"", "\"\""); return (v.contains(";") || v.contains("\n") || v.contains("\"")) ? "\"" + v + "\"" : v; }

    // ---------------------------------------------------------
    // HELPERS: UI
    // ---------------------------------------------------------

    private LinearLayout baseScreen(boolean roomy) {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG);
        root.setPadding(dp(14), roomy ? dp(16) : dp(10), dp(14), dp(8)); return root;
    }

    private ScrollView wrapInScroll(View child) { ScrollView sv = new ScrollView(this); sv.setFillViewport(true); sv.addView(child); return sv; }

    private void addBrandHeader(LinearLayout root, String title, String subtitle) {
        LinearLayout top = new LinearLayout(this); top.setOrientation(LinearLayout.HORIZONTAL); top.setGravity(Gravity.CENTER_VERTICAL); top.setPadding(dp(2), 0, dp(2), dp(8));
        LinearLayout brand = new LinearLayout(this); brand.setOrientation(LinearLayout.VERTICAL);
        TextView logo = titleText("Sparki • v4"); logo.setTextColor(GREEN); logo.setTextSize(16); brand.addView(logo);
        TextView name = titleText(title); name.setTextSize(24); brand.addView(name);
        TextView sub = smallText(subtitle); sub.setTextSize(12); sub.setPadding(0, dp(1), 0, 0); brand.addView(sub);
        top.addView(brand, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView person = titleText("♙"); person.setTextSize(26); person.setGravity(Gravity.CENTER); person.setTextColor(GREEN_DARK); top.addView(person, new LinearLayout.LayoutParams(dp(44), dp(44)));
        root.addView(top);
    }

    private void addSimpleHeader(LinearLayout root, String title, String subtitle, boolean back) {
        if (back) { Button b = textButton("← Terug"); b.setOnClickListener(v -> showMapHome()); root.addView(b, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(40))); }
        TextView t = titleText(title); t.setTextSize(27); root.addView(t); TextView s = smallText(subtitle); s.setPadding(0, dp(4), 0, dp(14)); root.addView(s);
    }

    private LinearLayout progressStrip(StreetSession s) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(2), dp(8), dp(2), dp(5));
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL);
        TextView left = titleText(s.visitedCount() + " / " + s.houses.size() + " gedaan"); left.setTextSize(14); row.addView(left, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        int pct = s.houses.isEmpty() ? 0 : Math.round(s.visitedCount() * 100f / s.houses.size()); TextView right = smallText(pct + "%"); row.addView(right); box.addView(row);
        ProgressBar p = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal); p.setMax(Math.max(1, s.houses.size())); p.setProgress(s.visitedCount()); p.setProgressTintList(android.content.res.ColorStateList.valueOf(GREEN));
        box.addView(p, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(14))); return box;
    }

    private LinearLayout segmentedControl() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setPadding(dp(3), dp(3), dp(3), dp(3)); l.setBackground(roundRect(Color.WHITE, BORDER, 14)); return l; }
    private Button segmentButton(String text, boolean active) { return compactButton(text, active ? GREEN : Color.WHITE, Color.BLACK, active ? GREEN : BORDER); }

    private LinearLayout bottomNav(String active) {
        LinearLayout nav = new LinearLayout(this); nav.setOrientation(LinearLayout.HORIZONTAL); nav.setGravity(Gravity.CENTER); nav.setPadding(0, dp(4), 0, 0); nav.setBackgroundColor(Color.WHITE);
        nav.addView(navButton("⌂", "Kaart", "map".equals(active), v -> showMapHome()), weightNoMargin());
        nav.addView(navButton("▣", "Afspraken", "appointments".equals(active), v -> showAppointments()), weightNoMargin());
        nav.addView(navButton("▥", "Dashboard", "dashboard".equals(active), v -> showDashboard()), weightNoMargin());
        nav.addView(navButton("♙", "Team", "team".equals(active), v -> showTeam()), weightNoMargin());
        return nav;
    }

    private LinearLayout navButton(String icon, String label, boolean active, View.OnClickListener listener) {
        LinearLayout b = new LinearLayout(this); b.setOrientation(LinearLayout.VERTICAL); b.setGravity(Gravity.CENTER); b.setPadding(dp(2), dp(5), dp(2), dp(3));
        TextView i = titleText(icon); i.setTextSize(19); i.setTextColor(active ? GREEN : MUTED); b.addView(i);
        TextView l = smallText(label); l.setTextSize(10); l.setTextColor(active ? GREEN : MUTED); b.addView(l); b.setOnClickListener(listener); return b;
    }

    private LinearLayout card() { LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(14), dp(14), dp(14), dp(14)); c.setBackground(roundRect(CARD, BORDER, 16)); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); p.setMargins(0, dp(5), 0, dp(5)); c.setLayoutParams(p); return c; }
    private LinearLayout statCard(String label, String value) { LinearLayout c = card(); TextView v = titleText(value); v.setTextSize(25); v.setTextColor(GREEN_DARK); c.addView(v); c.addView(smallText(label)); return c; }
    private LinearLayout statusRow() { LinearLayout r = new LinearLayout(this); r.setOrientation(LinearLayout.HORIZONTAL); r.setGravity(Gravity.CENTER_VERTICAL); r.setPadding(0, dp(5), 0, 0); return r; }

    private LinearLayout labeled(String label, EditText field) { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.addView(label(label)); l.addView(field); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); p.bottomMargin = dp(9); l.setLayoutParams(p); return l; }
    private TextView label(String text) { TextView t = titleText(text); t.setTextSize(13); t.setPadding(dp(2), dp(3), 0, dp(5)); return t; }
    private EditText field(String contentDescription, String hint) { EditText e = new EditText(this); e.setContentDescription(contentDescription); e.setHint(hint); e.setTextColor(TEXT); e.setHintTextColor(Color.rgb(151, 160, 155)); e.setTextSize(15); e.setPadding(dp(11), dp(8), dp(11), dp(8)); e.setBackground(roundRect(Color.WHITE, BORDER, 12)); e.setMinHeight(dp(44)); return e; }
    private EditText numberField(String contentDescription, String hint) { EditText e = field(contentDescription, hint); e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER); e.setSingleLine(true); return e; }
    private RadioButton radio(String text) { RadioButton r = new RadioButton(this); r.setText(text); r.setTextColor(TEXT); r.setButtonTintList(android.content.res.ColorStateList.valueOf(GREEN)); r.setTextSize(13); return r; }

    private Button primaryButton(String text) { return button(text, GREEN, Color.BLACK, GREEN, 15); }
    private Button secondaryButton(String text) { return button(text, Color.WHITE, TEXT, BORDER, 14); }
    private Button compactButton(String text, int bg, int fg, int stroke) { return button(text, bg, fg, stroke, 12); }
    private Button quickStatus(String text, int color) { return button(text, tint(color, 0.10f), color, tint(color, 0.30f), 11); }
    private Button textButton(String text) { Button b = new Button(this); b.setText(text); b.setTextColor(Color.BLACK); b.setTextSize(14); b.setAllCaps(false); b.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL); b.setPadding(0, 0, 0, 0); b.setBackgroundColor(Color.TRANSPARENT); return b; }
    private Button button(String text, int bg, int fg, int stroke, int textSize) { Button b = new Button(this); b.setText(text); b.setTextColor(Color.BLACK); b.setTextSize(textSize); b.setAllCaps(false); b.setTypeface(Typeface.DEFAULT_BOLD); b.setGravity(Gravity.CENTER); b.setPadding(dp(7), dp(6), dp(7), dp(6)); b.setBackground(roundRect(bg, stroke, 12)); return b; }

    private TextView titleText(String text) { TextView t = new TextView(this); t.setText(text); t.setTextColor(TEXT); t.setTypeface(Typeface.DEFAULT_BOLD); return t; }
    private TextView smallText(String text) { TextView t = new TextView(this); t.setText(text); t.setTextColor(MUTED); t.setTextSize(13); return t; }

    private LinearLayout.LayoutParams fullButtonParams() { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(50)); p.setMargins(0, dp(4), 0, dp(4)); return p; }
    private LinearLayout.LayoutParams weightParams() { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f); p.setMargins(dp(4), dp(3), dp(4), dp(3)); return p; }
    private LinearLayout.LayoutParams weightNoMargin() { return new LinearLayout.LayoutParams(0, dp(52), 1f); }
    private LinearLayout.LayoutParams weightCompact() { LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, dp(42), 1f); p.setMargins(dp(2), 0, dp(2), 0); return p; }

    private GradientDrawable roundRect(int fill, int stroke, int radiusDp) { GradientDrawable g = new GradientDrawable(); g.setColor(fill); g.setCornerRadius(dp(radiusDp)); g.setStroke(dp(1), stroke); return g; }

    private int colorForStatus(String status) {
        if (STATUS_CUSTOMER.equals(status)) return GREEN;
        if (STATUS_APPOINTMENT.equals(status)) return BLUE;
        if (STATUS_INTEREST.equals(status)) return YELLOW;
        if (STATUS_NOT_HOME.equals(status)) return RED;
        if (STATUS_NO_INTEREST.equals(status)) return GRAY;
        if (STATUS_LATER.equals(status)) return PURPLE;
        return Color.rgb(166, 178, 171);
    }

    private int tint(int color, float whiteAmount) {
        int r = (int)(Color.red(color) * (1f - whiteAmount) + 255 * whiteAmount);
        int g = (int)(Color.green(color) * (1f - whiteAmount) + 255 * whiteAmount);
        int b = (int)(Color.blue(color) * (1f - whiteAmount) + 255 * whiteAmount);
        return Color.rgb(r, g, b);
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }
}
