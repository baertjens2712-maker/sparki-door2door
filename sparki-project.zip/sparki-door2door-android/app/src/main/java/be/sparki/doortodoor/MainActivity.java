package be.sparki.doortodoor;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.CalendarContract;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class MainActivity extends Activity {

    public static final String STATUS_NONE = "Niet bezocht";
    public static final String STATUS_NOT_HOME = "Niet thuis";
    public static final String STATUS_NO_INTEREST = "Geen interesse";
    public static final String STATUS_INTEREST = "Interesse";
    public static final String STATUS_APPOINTMENT = "Afspraak gemaakt";
    public static final String STATUS_CUSTOMER = "Contract / klant";
    public static final String STATUS_LATER = "Later teruggaan";

    public static final String SIDE_ODD = "Oneven";
    public static final String SIDE_EVEN = "Even";
    public static final String SIDE_ALL = "Alles";

    private static final int EXPORT_REQUEST = 9001;
    private static final int TEAM_EXPORT_REQUEST = 9002;
    private static final int TEAM_IMPORT_REQUEST = 9003;

    private static final int BG = Color.rgb(247, 248, 246);
    private static final int CARD = Color.WHITE;
    private static final int TEXT = Color.rgb(31, 41, 39);
    private static final int MUTED = Color.rgb(103, 116, 112);
    private static final int ACCENT = Color.rgb(21, 111, 101);
    private static final int ACCENT_DARK = Color.rgb(13, 78, 72);
    private static final int BORDER = Color.rgb(224, 229, 226);

    private Storage storage;
    private String pendingCsv = null;
    private String pendingTeamJson = null;
    private String currentScreen = "home";

    private static class AppointmentItem {
        StreetSession session;
        HouseVisit house;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(ACCENT_DARK);
        storage = new Storage(this);
        showHome();
    }

    @Override
    public void onBackPressed() {
        if ("home".equals(currentScreen)) super.onBackPressed();
        else showHome();
    }

    private void showHome() {
        currentScreen = "home";
        List<StreetSession> sessions = storage.loadAll();
        LinearLayout root = baseScreen();

        addHeader(root, "Sparki Door2Door", "v2 • straten, afspraken en teamdelen", false);

        int totalVisited = 0, totalInterest = 0, totalAppointments = 0, totalCustomers = 0;
        for (StreetSession s : sessions) {
            totalVisited += s.visitedCount();
            totalInterest += s.countStatus(STATUS_INTEREST);
            totalCustomers += s.countStatus(STATUS_CUSTOMER);
            for (HouseVisit h : s.houses) if (h.appointmentAt > 0) totalAppointments++;
        }

        LinearLayout stats = horizontalRow();
        stats.addView(statCard("Bezocht", String.valueOf(totalVisited)), weightParams());
        stats.addView(statCard("Interesse", String.valueOf(totalInterest)), weightParams());
        root.addView(stats);

        LinearLayout stats2 = horizontalRow();
        stats2.addView(statCard("Afspraken", String.valueOf(totalAppointments)), weightParams());
        stats2.addView(statCard("Klanten", String.valueOf(totalCustomers)), weightParams());
        root.addView(stats2);

        Button newStreet = primaryButton("+ Nieuwe straat starten");
        newStreet.setOnClickListener(v -> showNewStreet());
        root.addView(newStreet, fullButtonParams());

        Button appointments = secondaryButton("📅 Afsprakenlijst");
        appointments.setOnClickListener(v -> showAppointments());
        root.addView(appointments, fullButtonParams());

        if (!sessions.isEmpty()) {
            StreetSession latest = sessions.get(0);
            Button resume = secondaryButton("Hervat: " + latest.street);
            resume.setOnClickListener(v -> showSession(latest.id));
            root.addView(resume, fullButtonParams());
        }

        Button history = secondaryButton("Straatgeschiedenis");
        history.setOnClickListener(v -> showHistory());
        root.addView(history, fullButtonParams());

        Button team = secondaryButton("👥 Team delen / samenvoegen");
        team.setOnClickListener(v -> showTeam());
        root.addView(team, fullButtonParams());

        Button export = secondaryButton("Exporteer resultaten naar CSV");
        export.setOnClickListener(v -> exportCsv());
        root.addView(export, fullButtonParams());

        TextView tip = smallText("Teamdelen in v2 werkt via een gedeeld backupbestand dat resultaten slim samenvoegt. Daardoor kunnen jij en je collega dezelfde straatdata uitwisselen zonder dubbel werk. Live cloud-synchronisatie kan hier later bovenop worden gezet.");
        tip.setPadding(dp(4), dp(12), dp(4), dp(24));
        root.addView(tip);

        setContentView(wrapInScroll(root));
    }

    private void showNewStreet() {
        currentScreen = "new";
        LinearLayout root = baseScreen();
        addHeader(root, "Nieuwe straat", "Vul één keer het bereik in. De app maakt daarna automatisch de huisnummers.", true);

        EditText advisor = field("Sales advisor", "Bijv. Jens");
        EditText municipality = field("Gemeente", "Bijv. Lede");
        EditText street = field("Straatnaam", "Bijv. Stationsstraat");
        EditText from = numberField("Van huisnummer", "1");
        EditText to = numberField("Tot huisnummer", "99");

        root.addView(labeled("Sales advisor", advisor));
        root.addView(labeled("Gemeente", municipality));
        root.addView(labeled("Straatnaam", street));

        LinearLayout nums = horizontalRow();
        LinearLayout left = new LinearLayout(this); left.setOrientation(LinearLayout.VERTICAL);
        left.addView(label("Van nummer")); left.addView(from);
        LinearLayout right = new LinearLayout(this); right.setOrientation(LinearLayout.VERTICAL);
        right.addView(label("Tot nummer")); right.addView(to);
        nums.addView(left, weightParams()); nums.addView(right, weightParams());
        root.addView(nums);

        root.addView(label("Welke kant doe je?"));
        RadioGroup sideGroup = new RadioGroup(this);
        sideGroup.setOrientation(RadioGroup.HORIZONTAL);
        RadioButton odd = radio("Oneven"); odd.setId(View.generateViewId()); odd.setChecked(true);
        RadioButton even = radio("Even"); even.setId(View.generateViewId());
        RadioButton all = radio("Alles"); all.setId(View.generateViewId());
        sideGroup.addView(odd, weightParams()); sideGroup.addView(even, weightParams()); sideGroup.addView(all, weightParams());
        root.addView(sideGroup);

        TextView preview = smallText("Voorbeeld: 1, 3, 5, 7, 9 …");
        preview.setPadding(0, dp(8), 0, dp(12));
        root.addView(preview);
        sideGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == odd.getId()) preview.setText("Voorbeeld: 1, 3, 5, 7, 9 …");
            else if (checkedId == even.getId()) preview.setText("Voorbeeld: 2, 4, 6, 8, 10 …");
            else preview.setText("Voorbeeld: 1, 2, 3, 4, 5 …");
        });

        Button start = primaryButton("Start deze straat");
        start.setOnClickListener(v -> {
            String advisorText = advisor.getText().toString().trim();
            String municipalityText = municipality.getText().toString().trim();
            String streetText = street.getText().toString().trim();
            if (streetText.isEmpty()) { street.setError("Vul een straatnaam in"); return; }
            int startNo, endNo;
            try {
                startNo = Integer.parseInt(from.getText().toString().trim());
                endNo = Integer.parseInt(to.getText().toString().trim());
            } catch (Exception e) {
                Toast.makeText(this, "Vul geldige huisnummers in.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (startNo > endNo) { int temp = startNo; startNo = endNo; endNo = temp; }
            String side = odd.isChecked() ? SIDE_ODD : even.isChecked() ? SIDE_EVEN : SIDE_ALL;
            StreetSession s = new StreetSession();
            s.id = UUID.randomUUID().toString();
            s.advisor = advisorText;
            s.municipality = municipalityText;
            s.street = streetText;
            s.startNumber = startNo;
            s.endNumber = endNo;
            s.side = side;
            s.createdAt = System.currentTimeMillis();
            s.updatedAt = s.createdAt;
            s.currentIndex = 0;
            for (int n = startNo; n <= endNo; n++) {
                if (SIDE_ALL.equals(side) || (SIDE_ODD.equals(side) && n % 2 != 0) || (SIDE_EVEN.equals(side) && n % 2 == 0)) {
                    s.houses.add(new HouseVisit(n));
                }
            }
            if (s.houses.isEmpty()) {
                Toast.makeText(this, "Er zijn geen huisnummers in dit bereik voor deze kant.", Toast.LENGTH_LONG).show();
                return;
            }
            storage.save(s);
            showSession(s.id);
        });
        root.addView(start, fullButtonParams());

        setContentView(wrapInScroll(root));
    }

    private void showSession(String id) {
        currentScreen = "session";
        StreetSession s = storage.find(id);
        if (s == null || s.houses.isEmpty()) { showHome(); return; }
        if (s.currentIndex < 0) s.currentIndex = 0;
        if (s.currentIndex >= s.houses.size()) s.currentIndex = s.houses.size() - 1;
        HouseVisit house = s.houses.get(s.currentIndex);

        LinearLayout root = baseScreen();
        addHeader(root, s.street, streetSubtitle(s), true);

        LinearLayout progressCard = card();
        TextView progressText = titleText(s.visitedCount() + " van " + s.houses.size() + " bezocht");
        progressText.setTextSize(18);
        progressCard.addView(progressText);
        ProgressBar progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(s.houses.size());
        progress.setProgress(s.visitedCount());
        progress.setProgressTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        progress.setPadding(0, dp(10), 0, dp(8));
        progressCard.addView(progress, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(28)));
        progressCard.addView(smallText("Niet thuis " + s.countStatus(STATUS_NOT_HOME) + "  •  Interesse " + s.countStatus(STATUS_INTEREST) + "  •  Afspraken " + countAppointments(s)));
        root.addView(progressCard);

        LinearLayout houseCard = card();
        TextView small = smallText("HUIDIGE DEUR");
        small.setTypeface(Typeface.DEFAULT_BOLD); small.setTextColor(ACCENT);
        houseCard.addView(small);
        TextView number = titleText("Huisnummer " + house.number);
        number.setTextSize(32); number.setPadding(0, dp(4), 0, dp(4));
        houseCard.addView(number);
        houseCard.addView(smallText("Status: " + house.status));
        if (house.appointmentAt > 0) {
            TextView ap = smallText("📅 Afspraak: " + formatDateTime(house.appointmentAt));
            ap.setTextColor(ACCENT_DARK); ap.setTypeface(Typeface.DEFAULT_BOLD);
            ap.setPadding(0, dp(7), 0, 0);
            houseCard.addView(ap);
        }
        root.addView(houseCard);

        EditText note = field("Notitie", "Bijv. terugkomen na 18u");
        note.setText(house.note == null ? "" : house.note);
        root.addView(labeled("Korte notitie (optioneel)", note));

        Button appointment = secondaryButton(house.appointmentAt > 0 ? "📅 Wijzig datum / uur afspraak" : "📅 Plan afspraak voor dit huisnummer");
        appointment.setOnClickListener(v -> planAppointment(s, house, note));
        root.addView(appointment, fullButtonParams());

        root.addView(label("Tik op het resultaat — de app gaat automatisch naar de volgende deur:"));
        addStatusRows(root, s, house, note);

        LinearLayout nav = horizontalRow();
        Button prev = secondaryButton("← Vorige");
        prev.setEnabled(s.currentIndex > 0); prev.setAlpha(prev.isEnabled() ? 1f : 0.45f);
        prev.setOnClickListener(v -> {
            saveCurrentNote(s, house, note);
            s.currentIndex = Math.max(0, s.currentIndex - 1);
            storage.save(s); showSession(s.id);
        });
        Button next = secondaryButton("Volgende →");
        next.setEnabled(s.currentIndex < s.houses.size() - 1); next.setAlpha(next.isEnabled() ? 1f : 0.45f);
        next.setOnClickListener(v -> {
            saveCurrentNote(s, house, note);
            s.currentIndex = Math.min(s.houses.size() - 1, s.currentIndex + 1);
            storage.save(s); showSession(s.id);
        });
        nav.addView(prev, weightParams()); nav.addView(next, weightParams()); root.addView(nav);

        Button summary = secondaryButton("Bekijk samenvatting van deze straat");
        summary.setOnClickListener(v -> showSummary(s.id));
        root.addView(summary, fullButtonParams());

        setContentView(wrapInScroll(root));
    }

    private void addStatusRows(LinearLayout root, StreetSession s, HouseVisit house, EditText note) {
        String[][] statuses = {
                {STATUS_NOT_HOME, "Niet thuis"},
                {STATUS_NO_INTEREST, "Geen interesse"},
                {STATUS_INTEREST, "Interesse"},
                {STATUS_APPOINTMENT, "Afspraak maken"},
                {STATUS_CUSTOMER, "Contract / klant"},
                {STATUS_LATER, "Later teruggaan"}
        };
        for (int i = 0; i < statuses.length; i += 2) {
            LinearLayout row = horizontalRow();
            for (int j = 0; j < 2 && i + j < statuses.length; j++) {
                String status = statuses[i + j][0];
                String buttonLabel = statuses[i + j][1];
                Button b = statusButton(buttonLabel, colorForStatus(status));
                b.setOnClickListener(v -> {
                    if (STATUS_APPOINTMENT.equals(status)) {
                        planAppointment(s, house, note);
                    } else {
                        saveStatusAndAdvance(s, house, note, status);
                    }
                });
                row.addView(b, weightParams());
            }
            root.addView(row);
        }
    }

    private void planAppointment(StreetSession s, HouseVisit house, EditText note) {
        Calendar c = Calendar.getInstance();
        if (house.appointmentAt > 0) c.setTimeInMillis(house.appointmentAt);
        else { c.add(Calendar.DAY_OF_MONTH, 1); c.set(Calendar.HOUR_OF_DAY, 18); c.set(Calendar.MINUTE, 0); }

        DatePickerDialog dateDialog = new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            Calendar selected = Calendar.getInstance();
            selected.set(year, month, dayOfMonth, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), 0);
            TimePickerDialog timeDialog = new TimePickerDialog(this, (timeView, hourOfDay, minute) -> {
                selected.set(Calendar.HOUR_OF_DAY, hourOfDay);
                selected.set(Calendar.MINUTE, minute);
                selected.set(Calendar.SECOND, 0);
                selected.set(Calendar.MILLISECOND, 0);

                house.note = note.getText().toString().trim();
                house.status = STATUS_APPOINTMENT;
                house.appointmentAt = selected.getTimeInMillis();
                house.updatedAt = System.currentTimeMillis();
                s.updatedAt = house.updatedAt;
                storage.save(s);

                new AlertDialog.Builder(this)
                        .setTitle("Afspraak opgeslagen")
                        .setMessage(s.street + " " + house.number + "\n" + formatDateTime(house.appointmentAt))
                        .setNegativeButton("Blijf bij deze deur", (d, w) -> showSession(s.id))
                        .setPositiveButton("Volgende deur", (d, w) -> advanceAfterVisit(s))
                        .show();
            }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), true);
            timeDialog.setTitle("Kies het uur");
            timeDialog.show();
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH));
        dateDialog.setTitle("Kies de datum");
        dateDialog.show();
    }

    private void saveStatusAndAdvance(StreetSession s, HouseVisit house, EditText note, String status) {
        house.note = note.getText().toString().trim();
        house.status = status;
        house.updatedAt = System.currentTimeMillis();
        s.updatedAt = house.updatedAt;
        storage.save(s);
        advanceAfterVisit(s);
    }

    private void advanceAfterVisit(StreetSession s) {
        int nextIndex = findNextUnvisited(s, s.currentIndex + 1);
        if (nextIndex < 0) nextIndex = findNextUnvisited(s, 0);
        if (nextIndex >= 0) {
            s.currentIndex = nextIndex;
            storage.save(s);
            showSession(s.id);
        } else showSummary(s.id);
    }

    private void showAppointments() {
        currentScreen = "appointments";
        List<AppointmentItem> items = collectAppointments();
        LinearLayout root = baseScreen();
        addHeader(root, "Afsprakenlijst", "Alle geplande afspraken, automatisch op datum en uur gesorteerd.", true);

        if (items.isEmpty()) {
            root.addView(smallText("Nog geen afspraken gepland."));
            setContentView(wrapInScroll(root));
            return;
        }

        String lastDay = "";
        SimpleDateFormat dayFmt = new SimpleDateFormat("EEEE d MMMM", new Locale("nl", "BE"));
        long now = System.currentTimeMillis();
        for (AppointmentItem item : items) {
            String day = dayFmt.format(new Date(item.house.appointmentAt));
            if (!day.equals(lastDay)) {
                TextView section = label(day.substring(0, 1).toUpperCase() + day.substring(1));
                section.setTextSize(17); section.setPadding(dp(2), dp(14), 0, dp(7));
                root.addView(section); lastDay = day;
            }

            LinearLayout c = card();
            TextView title = titleText(formatTime(item.house.appointmentAt) + "  •  " + item.session.street + " " + item.house.number);
            title.setTextSize(18); c.addView(title);
            c.addView(smallText((item.session.municipality == null ? "" : item.session.municipality) + advisorSuffix(item.session)));
            if (item.house.note != null && !item.house.note.trim().isEmpty()) {
                TextView note = smallText("Notitie: " + item.house.note);
                note.setPadding(0, dp(6), 0, 0); c.addView(note);
            }
            if (item.house.appointmentAt < now) {
                TextView past = smallText("Voorbij"); past.setTextColor(Color.rgb(160, 90, 70)); past.setTypeface(Typeface.DEFAULT_BOLD); c.addView(past);
            }

            LinearLayout actions = horizontalRow();
            Button openStreet = secondaryButton("Open deur");
            openStreet.setOnClickListener(v -> {
                int idx = indexOfHouse(item.session, item.house.number);
                if (idx >= 0) item.session.currentIndex = idx;
                storage.save(item.session); showSession(item.session.id);
            });
            Button maps = secondaryButton("Maps");
            maps.setOnClickListener(v -> openMaps(item.session, item.house));
            actions.addView(openStreet, weightParams()); actions.addView(maps, weightParams()); c.addView(actions);

            LinearLayout actions2 = horizontalRow();
            Button calendar = secondaryButton("Agenda");
            calendar.setOnClickListener(v -> addToCalendar(item.session, item.house));
            Button remove = dangerButton("Verwijder afspraak");
            remove.setOnClickListener(v -> new AlertDialog.Builder(this)
                    .setTitle("Afspraak verwijderen?")
                    .setMessage(item.session.street + " " + item.house.number)
                    .setNegativeButton("Annuleren", null)
                    .setPositiveButton("Verwijderen", (d, w) -> {
                        item.house.appointmentAt = 0L;
                        if (STATUS_APPOINTMENT.equals(item.house.status)) item.house.status = STATUS_INTEREST;
                        item.house.updatedAt = System.currentTimeMillis();
                        item.session.updatedAt = item.house.updatedAt;
                        storage.save(item.session); showAppointments();
                    }).show());
            actions2.addView(calendar, weightParams()); actions2.addView(remove, weightParams()); c.addView(actions2);
            root.addView(c);
        }
        setContentView(wrapInScroll(root));
    }

    private List<AppointmentItem> collectAppointments() {
        List<AppointmentItem> items = new ArrayList<>();
        for (StreetSession s : storage.loadAll()) {
            for (HouseVisit h : s.houses) {
                if (h.appointmentAt > 0) {
                    AppointmentItem item = new AppointmentItem(); item.session = s; item.house = h; items.add(item);
                }
            }
        }
        Collections.sort(items, Comparator.comparingLong(a -> a.house.appointmentAt));
        return items;
    }

    private void openMaps(StreetSession s, HouseVisit h) {
        String address = s.street + " " + h.number + (isBlank(s.municipality) ? "" : ", " + s.municipality) + ", België";
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(address)));
        try { startActivity(intent); }
        catch (Exception e) { Toast.makeText(this, "Geen kaarten-app gevonden.", Toast.LENGTH_SHORT).show(); }
    }

    private void addToCalendar(StreetSession s, HouseVisit h) {
        if (h.appointmentAt <= 0) return;
        String address = s.street + " " + h.number + (isBlank(s.municipality) ? "" : ", " + s.municipality);
        Intent intent = new Intent(Intent.ACTION_INSERT);
        intent.setData(CalendarContract.Events.CONTENT_URI);
        intent.putExtra(CalendarContract.EXTRA_EVENT_BEGIN_TIME, h.appointmentAt);
        intent.putExtra(CalendarContract.EXTRA_EVENT_END_TIME, h.appointmentAt + 60 * 60 * 1000L);
        intent.putExtra(CalendarContract.Events.TITLE, "Sparki afspraak – " + s.street + " " + h.number);
        intent.putExtra(CalendarContract.Events.EVENT_LOCATION, address);
        intent.putExtra(CalendarContract.Events.DESCRIPTION, h.note == null ? "" : h.note);
        try { startActivity(intent); }
        catch (Exception e) { Toast.makeText(this, "Geen agenda-app gevonden.", Toast.LENGTH_SHORT).show(); }
    }

    private void showTeam() {
        currentScreen = "team";
        LinearLayout root = baseScreen();
        addHeader(root, "Team delen", "Wissel gegevens uit met je collega en voeg wijzigingen samen.", true);

        LinearLayout info = card();
        TextView t = titleText("Zo werkt het"); t.setTextSize(19); info.addView(t);
        info.addView(smallText("1. Exporteer jouw team-backup.\n2. Deel het bestand met je collega.\n3. Je collega kiest Importeren en samenvoegen.\n4. De nieuwste wijziging per huisnummer blijft behouden."));
        root.addView(info);

        Button export = primaryButton("Exporteer team-backup");
        export.setOnClickListener(v -> exportTeamBackup());
        root.addView(export, fullButtonParams());

        Button importBtn = secondaryButton("Importeer en voeg samen");
        importBtn.setOnClickListener(v -> importTeamBackup());
        root.addView(importBtn, fullButtonParams());

        LinearLayout cloud = card();
        TextView ct = titleText("Live synchronisatie"); ct.setTextSize(18); cloud.addView(ct);
        cloud.addView(smallText("De app is nu voorbereid op samenwerking. Voor volledig live synchroniseren tussen twee telefoons is nog een beveiligde cloud-database nodig, bijvoorbeeld Supabase. De backupmethode hierboven werkt nu al zonder abonnement of account."));
        root.addView(cloud);

        setContentView(wrapInScroll(root));
    }

    private void exportTeamBackup() {
        pendingTeamJson = storage.exportJson();
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        intent.putExtra(Intent.EXTRA_TITLE, "sparki-team-" + new SimpleDateFormat("yyyyMMdd-HHmm", Locale.getDefault()).format(new Date()) + ".json");
        startActivityForResult(intent, TEAM_EXPORT_REQUEST);
    }

    private void importTeamBackup() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/json");
        startActivityForResult(intent, TEAM_IMPORT_REQUEST);
    }

    private void showSummary(String id) {
        currentScreen = "summary";
        StreetSession s = storage.find(id);
        if (s == null) { showHome(); return; }
        LinearLayout root = baseScreen();
        addHeader(root, "Straatsamenvatting", streetSubtitle(s), true);

        LinearLayout card = card();
        card.addView(summaryLine("Bezocht", s.visitedCount() + " / " + s.houses.size()));
        card.addView(summaryLine("Niet thuis", String.valueOf(s.countStatus(STATUS_NOT_HOME))));
        card.addView(summaryLine("Geen interesse", String.valueOf(s.countStatus(STATUS_NO_INTEREST))));
        card.addView(summaryLine("Interesse", String.valueOf(s.countStatus(STATUS_INTEREST))));
        card.addView(summaryLine("Afspraken", String.valueOf(countAppointments(s))));
        card.addView(summaryLine("Contract / klant", String.valueOf(s.countStatus(STATUS_CUSTOMER))));
        card.addView(summaryLine("Later teruggaan", String.valueOf(s.countStatus(STATUS_LATER))));
        root.addView(card);

        TextView todo = smallText("Nog niet bezocht: " + remainingNumbers(s));
        todo.setPadding(dp(4), dp(10), dp(4), dp(10)); root.addView(todo);

        Button resume = primaryButton(s.visitedCount() == s.houses.size() ? "Straat opnieuw bekijken" : "Ga verder met deze straat");
        resume.setOnClickListener(v -> {
            int next = findNextUnvisited(s, 0); if (next >= 0) s.currentIndex = next;
            storage.save(s); showSession(s.id);
        });
        root.addView(resume, fullButtonParams());

        Button appointments = secondaryButton("Bekijk afspraken");
        appointments.setOnClickListener(v -> showAppointments()); root.addView(appointments, fullButtonParams());

        Button home = secondaryButton("Terug naar dashboard");
        home.setOnClickListener(v -> showHome()); root.addView(home, fullButtonParams());

        setContentView(wrapInScroll(root));
    }

    private void showHistory() {
        currentScreen = "history";
        List<StreetSession> sessions = storage.loadAll();
        LinearLayout root = baseScreen();
        addHeader(root, "Straatgeschiedenis", "Alle straten die op dit toestel zijn aangemaakt.", true);

        if (sessions.isEmpty()) root.addView(smallText("Nog geen straten geregistreerd."));

        for (StreetSession s : sessions) {
            LinearLayout c = card();
            TextView t = titleText(s.street); t.setTextSize(19); c.addView(t);
            c.addView(smallText(streetSubtitle(s)));
            c.addView(smallText(s.visitedCount() + "/" + s.houses.size() + " bezocht  •  " + s.countStatus(STATUS_INTEREST) + " interesse  •  " + countAppointments(s) + " afspraken"));

            LinearLayout actions = horizontalRow();
            Button open = secondaryButton("Open"); open.setOnClickListener(v -> showSession(s.id));
            Button delete = dangerButton("Verwijder");
            delete.setOnClickListener(v -> new AlertDialog.Builder(this)
                    .setTitle("Straat verwijderen?")
                    .setMessage("Alle resultaten voor " + s.street + " worden van dit toestel verwijderd.")
                    .setNegativeButton("Annuleren", null)
                    .setPositiveButton("Verwijderen", (dialog, which) -> { storage.delete(s.id); showHistory(); }).show());
            actions.addView(open, weightParams()); actions.addView(delete, weightParams()); c.addView(actions); root.addView(c);
        }
        setContentView(wrapInScroll(root));
    }

    private void exportCsv() {
        List<StreetSession> sessions = storage.loadAll();
        if (sessions.isEmpty()) { Toast.makeText(this, "Er zijn nog geen gegevens om te exporteren.", Toast.LENGTH_SHORT).show(); return; }
        StringBuilder csv = new StringBuilder();
        csv.append("Datum;Sales advisor;Gemeente;Straat;Huisnummer;Kant;Status;Afspraak;Notitie\n");
        SimpleDateFormat fmt = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault());
        for (StreetSession s : sessions) {
            for (HouseVisit h : s.houses) {
                if (STATUS_NONE.equals(h.status) && h.appointmentAt <= 0) continue;
                String date = h.updatedAt > 0 ? fmt.format(new Date(h.updatedAt)) : "";
                String appointment = h.appointmentAt > 0 ? fmt.format(new Date(h.appointmentAt)) : "";
                csv.append(escapeCsv(date)).append(';').append(escapeCsv(s.advisor)).append(';')
                        .append(escapeCsv(s.municipality)).append(';').append(escapeCsv(s.street)).append(';')
                        .append(h.number).append(';').append(escapeCsv(s.side)).append(';').append(escapeCsv(h.status)).append(';')
                        .append(escapeCsv(appointment)).append(';').append(escapeCsv(h.note)).append('\n');
            }
        }
        pendingCsv = csv.toString();
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE); intent.setType("text/csv");
        intent.putExtra(Intent.EXTRA_TITLE, "sparki-door2door-" + new SimpleDateFormat("yyyyMMdd-HHmm", Locale.getDefault()).format(new Date()) + ".csv");
        startActivityForResult(intent, EXPORT_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        Uri uri = data.getData(); if (uri == null) return;

        if (requestCode == EXPORT_REQUEST && pendingCsv != null) {
            if (writeText(uri, pendingCsv)) Toast.makeText(this, "CSV opgeslagen.", Toast.LENGTH_LONG).show();
            pendingCsv = null;
        } else if (requestCode == TEAM_EXPORT_REQUEST && pendingTeamJson != null) {
            if (writeText(uri, pendingTeamJson)) Toast.makeText(this, "Team-backup opgeslagen.", Toast.LENGTH_LONG).show();
            pendingTeamJson = null;
        } else if (requestCode == TEAM_IMPORT_REQUEST) {
            try {
                String raw = readText(uri);
                int changed = storage.mergeJson(raw);
                if (changed < 0) Toast.makeText(this, "Dit is geen geldig Sparki team-bestand.", Toast.LENGTH_LONG).show();
                else {
                    Toast.makeText(this, changed + " wijzigingen samengevoegd.", Toast.LENGTH_LONG).show();
                    showHome();
                }
            } catch (Exception e) { Toast.makeText(this, "Importeren mislukt.", Toast.LENGTH_LONG).show(); }
        }
    }

    private boolean writeText(Uri uri, String text) {
        try (OutputStream out = getContentResolver().openOutputStream(uri)) {
            if (out != null) { out.write(text.getBytes(StandardCharsets.UTF_8)); return true; }
        } catch (Exception e) { Toast.makeText(this, "Opslaan mislukt: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
        return false;
    }

    private String readText(Uri uri) throws Exception {
        try (InputStream in = getContentResolver().openInputStream(uri); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            if (in == null) return "";
            byte[] buffer = new byte[8192]; int n;
            while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
            return out.toString(StandardCharsets.UTF_8.name());
        }
    }

    private int findNextUnvisited(StreetSession s, int start) {
        for (int i = Math.max(0, start); i < s.houses.size(); i++) if (STATUS_NONE.equals(s.houses.get(i).status)) return i;
        return -1;
    }

    private int indexOfHouse(StreetSession s, int number) {
        for (int i = 0; i < s.houses.size(); i++) if (s.houses.get(i).number == number) return i;
        return -1;
    }

    private int countAppointments(StreetSession s) {
        int count = 0; for (HouseVisit h : s.houses) if (h.appointmentAt > 0) count++; return count;
    }

    private void saveCurrentNote(StreetSession s, HouseVisit house, EditText note) {
        String newNote = note.getText().toString().trim();
        if (!newNote.equals(house.note == null ? "" : house.note)) house.updatedAt = System.currentTimeMillis();
        house.note = newNote; s.updatedAt = Math.max(s.updatedAt, System.currentTimeMillis()); storage.save(s);
    }

    private String remainingNumbers(StreetSession s) {
        List<String> nums = new ArrayList<>();
        for (HouseVisit h : s.houses) if (STATUS_NONE.equals(h.status)) nums.add(String.valueOf(h.number));
        if (nums.isEmpty()) return "geen — straat is volledig verwerkt";
        if (nums.size() > 24) return String.join(", ", nums.subList(0, 24)) + " … (" + nums.size() + " resterend)";
        return String.join(", ", nums);
    }

    private String streetSubtitle(StreetSession s) {
        String location = isBlank(s.municipality) ? "" : s.municipality + "  •  ";
        return location + s.side + " nummers " + s.startNumber + "–" + s.endNumber + advisorSuffix(s);
    }

    private String advisorSuffix(StreetSession s) { return isBlank(s.advisor) ? "" : "  •  " + s.advisor; }
    private boolean isBlank(String value) { return value == null || value.trim().isEmpty(); }

    private String formatDateTime(long millis) {
        return new SimpleDateFormat("dd/MM/yyyy 'om' HH:mm", new Locale("nl", "BE")).format(new Date(millis));
    }

    private String formatTime(long millis) { return new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date(millis)); }

    private String escapeCsv(String value) {
        if (value == null) return "";
        String v = value.replace("\"", "\"\"");
        if (v.contains(";") || v.contains("\n") || v.contains("\"")) return "\"" + v + "\"";
        return v;
    }

    // ---------- UI helpers ----------

    private LinearLayout baseScreen() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(30)); root.setBackgroundColor(BG); return root;
    }

    private ScrollView wrapInScroll(View child) {
        ScrollView sv = new ScrollView(this); sv.setFillViewport(true);
        sv.addView(child, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)); return sv;
    }

    private void addHeader(LinearLayout root, String title, String subtitle, boolean showBack) {
        if (showBack) {
            Button back = textButton("← Terug"); back.setOnClickListener(v -> showHome());
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(42)); bp.bottomMargin = dp(6); root.addView(back, bp);
        }
        TextView t = titleText(title); t.setTextSize(28); root.addView(t);
        TextView s = smallText(subtitle); s.setTextSize(14); s.setPadding(0, dp(5), 0, dp(16)); root.addView(s);
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setPadding(dp(16), dp(16), dp(16), dp(16));
        c.setBackground(roundRect(CARD, BORDER, 16));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); p.bottomMargin = dp(12); c.setLayoutParams(p); return c;
    }

    private LinearLayout statCard(String label, String value) {
        LinearLayout c = card(); c.getLayoutParams().width = 0; TextView v = titleText(value); v.setTextSize(25); c.addView(v); c.addView(smallText(label)); return c;
    }

    private TextView summaryLine(String left, String right) {
        TextView t = new TextView(this); t.setText(left + ":  " + right); t.setTextColor(TEXT); t.setTextSize(16); t.setPadding(0, dp(7), 0, dp(7)); return t;
    }

    private LinearLayout labeled(String label, EditText field) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL); box.addView(label(label)); box.addView(field);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); p.bottomMargin = dp(10); box.setLayoutParams(p); return box;
    }

    private TextView label(String text) {
        TextView t = new TextView(this); t.setText(text); t.setTextColor(TEXT); t.setTypeface(Typeface.DEFAULT_BOLD); t.setTextSize(14); t.setPadding(dp(2), dp(4), 0, dp(6)); return t;
    }

    private EditText field(String contentDescription, String hint) {
        EditText e = new EditText(this); e.setHint(hint); e.setContentDescription(contentDescription); e.setTextColor(TEXT); e.setHintTextColor(Color.rgb(150, 158, 155));
        e.setTextSize(16); e.setSingleLine(false); e.setPadding(dp(12), dp(10), dp(12), dp(10)); e.setBackground(roundRect(Color.WHITE, BORDER, 12)); e.setMinHeight(dp(48)); return e;
    }

    private EditText numberField(String contentDescription, String hint) {
        EditText e = field(contentDescription, hint); e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER); e.setSingleLine(true); return e;
    }

    private RadioButton radio(String text) {
        RadioButton r = new RadioButton(this); r.setText(text); r.setTextColor(TEXT); r.setTextSize(14); r.setButtonTintList(android.content.res.ColorStateList.valueOf(ACCENT)); return r;
    }

    private Button primaryButton(String text) { return button(text, ACCENT, Color.WHITE, ACCENT); }
    private Button secondaryButton(String text) { return button(text, Color.WHITE, TEXT, BORDER); }
    private Button dangerButton(String text) { return button(text, Color.WHITE, Color.rgb(166, 55, 55), Color.rgb(238, 199, 199)); }

    private Button textButton(String text) {
        Button b = new Button(this); b.setText(text); b.setTextColor(ACCENT_DARK); b.setTextSize(14); b.setAllCaps(false); b.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL); b.setPadding(0, 0, 0, 0); b.setBackgroundColor(Color.TRANSPARENT); return b;
    }

    private Button statusButton(String text, int color) { Button b = button(text, color, Color.WHITE, color); b.setTextSize(14); b.setMinHeight(dp(58)); return b; }

    private Button button(String text, int bg, int fg, int stroke) {
        Button b = new Button(this); b.setText(text); b.setTextColor(fg); b.setTextSize(15); b.setAllCaps(false); b.setTypeface(Typeface.DEFAULT_BOLD); b.setGravity(Gravity.CENTER);
        b.setPadding(dp(10), dp(9), dp(10), dp(9)); b.setBackground(roundRect(bg, stroke, 13)); return b;
    }

    private TextView titleText(String text) { TextView t = new TextView(this); t.setText(text); t.setTextColor(TEXT); t.setTypeface(Typeface.DEFAULT_BOLD); return t; }

    private TextView smallText(String text) {
        TextView t = new TextView(this); t.setText(text); t.setTextColor(MUTED); t.setTextSize(14); t.setLineSpacing(0, 1.12f); return t;
    }

    private LinearLayout horizontalRow() {
        LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL); row.setGravity(Gravity.CENTER_VERTICAL); row.setWeightSum(2f); return row;
    }

    private LinearLayout.LayoutParams weightParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f); p.setMargins(dp(4), dp(4), dp(4), dp(4)); return p;
    }

    private LinearLayout.LayoutParams fullButtonParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54)); p.setMargins(0, dp(5), 0, dp(5)); return p;
    }

    private GradientDrawable roundRect(int fill, int stroke, int radiusDp) {
        GradientDrawable g = new GradientDrawable(); g.setColor(fill); g.setCornerRadius(dp(radiusDp)); g.setStroke(dp(1), stroke); return g;
    }

    private int colorForStatus(String status) {
        switch (status) {
            case STATUS_NOT_HOME: return Color.rgb(222, 137, 53);
            case STATUS_NO_INTEREST: return Color.rgb(108, 117, 125);
            case STATUS_INTEREST: return Color.rgb(199, 153, 27);
            case STATUS_APPOINTMENT: return Color.rgb(63, 132, 78);
            case STATUS_CUSTOMER: return ACCENT;
            case STATUS_LATER: return Color.rgb(79, 106, 170);
            default: return ACCENT;
        }
    }

    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}
