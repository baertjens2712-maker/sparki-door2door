package be.sparki.doortodoor;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Space;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

public class MainActivity extends Activity {

    public static final String STATUS_NONE = "Niet bezocht";
    public static final String STATUS_NOT_HOME = "Niet thuis";
    public static final String STATUS_NO_INTEREST = "Geen interesse";
    public static final String STATUS_INTEREST = "Interesse";
    public static final String STATUS_APPOINTMENT = "Afspraak gemaakt";
    public static final String STATUS_CUSTOMER = "Contract / klant";
    public static final String STATUS_LATER = "Later teruggaan";

    public static final String SIDE_ODD = "Oneven";
    public static final String SIDE_EVEN = "Even";
    public static final String SIDE_ALL = "Alles";

    private static final int EXPORT_REQUEST = 9001;

    private static final int BG = Color.rgb(247, 248, 246);
    private static final int CARD = Color.WHITE;
    private static final int TEXT = Color.rgb(31, 41, 39);
    private static final int MUTED = Color.rgb(103, 116, 112);
    private static final int ACCENT = Color.rgb(21, 111, 101);
    private static final int ACCENT_DARK = Color.rgb(13, 78, 72);
    private static final int BORDER = Color.rgb(224, 229, 226);

    private Storage storage;
    private String pendingCsv = null;
    private String currentScreen = "home";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(ACCENT_DARK);
        storage = new Storage(this);
        showHome();
    }

    @Override
    public void onBackPressed() {
        if ("home".equals(currentScreen)) {
            super.onBackPressed();
        } else {
            showHome();
        }
    }

    private void showHome() {
        currentScreen = "home";
        List<StreetSession> sessions = storage.loadAll();
        LinearLayout root = baseScreen();

        addHeader(root, "Sparki Door2Door", "Sneller van deur tot deur, zonder nummers over te slaan.", false);

        int totalVisited = 0, totalInterest = 0, totalAppointments = 0, totalCustomers = 0;
        for (StreetSession s : sessions) {
            totalVisited += s.visitedCount();
            totalInterest += s.countStatus(STATUS_INTEREST);
            totalAppointments += s.countStatus(STATUS_APPOINTMENT);
            totalCustomers += s.countStatus(STATUS_CUSTOMER);
        }

        LinearLayout stats = horizontalRow();
        stats.addView(statCard("Bezocht", String.valueOf(totalVisited)), weightParams());
        stats.addView(statCard("Interesse", String.valueOf(totalInterest)), weightParams());
        root.addView(stats);

        LinearLayout stats2 = horizontalRow();
        stats2.addView(statCard("Afspraken", String.valueOf(totalAppointments)), weightParams());
        stats2.addView(statCard("Klanten", String.valueOf(totalCustomers)), weightParams());
        root.addView(stats2);

        Button newStreet = primaryButton("+ Nieuwe straat starten");
        newStreet.setOnClickListener(v -> showNewStreet());
        root.addView(newStreet, fullButtonParams());

        if (!sessions.isEmpty()) {
            StreetSession latest = sessions.get(0);
            Button resume = secondaryButton("Hervat: " + latest.street);
            resume.setOnClickListener(v -> showSession(latest.id));
            root.addView(resume, fullButtonParams());
        }

        Button history = secondaryButton("Straatgeschiedenis");
        history.setOnClickListener(v -> showHistory());
        root.addView(history, fullButtonParams());

        Button export = secondaryButton("Exporteer alle resultaten naar CSV");
        export.setOnClickListener(v -> exportCsv());
        root.addView(export, fullButtonParams());

        TextView tip = smallText("Tip: maak voor de andere kant van dezelfde straat een tweede sessie met even of oneven huisnummers. Zo kunnen twee advisors zonder dubbel werk canvassen.");
        tip.setPadding(dp(4), dp(12), dp(4), dp(24));
        root.addView(tip);

        setContentView(wrapInScroll(root));
    }

    private void showNewStreet() {
        currentScreen = "new";
        LinearLayout root = baseScreen();
        addHeader(root, "Nieuwe straat", "Vul één keer het bereik in. De app maakt daarna automatisch de huisnummers.", true);

        EditText advisor = field("Sales advisor", "Bijv. Joyce");
        EditText municipality = field("Gemeente", "Bijv. Lede");
        EditText street = field("Straatnaam", "Bijv. Stationsstraat");
        EditText from = numberField("Van huisnummer", "1");
        EditText to = numberField("Tot huisnummer", "99");

        root.addView(labeled("Sales advisor", advisor));
        root.addView(labeled("Gemeente", municipality));
        root.addView(labeled("Straatnaam", street));

        LinearLayout nums = horizontalRow();
        LinearLayout left = new LinearLayout(this); left.setOrientation(LinearLayout.VERTICAL);
        left.addView(label("Van nummer")); left.addView(from);
        LinearLayout right = new LinearLayout(this); right.setOrientation(LinearLayout.VERTICAL);
        right.addView(label("Tot nummer")); right.addView(to);
        nums.addView(left, weightParams()); nums.addView(right, weightParams());
        root.addView(nums);

        root.addView(label("Welke kant doe je?"));
        RadioGroup sideGroup = new RadioGroup(this);
        sideGroup.setOrientation(RadioGroup.HORIZONTAL);
        RadioButton odd = radio("Oneven"); odd.setId(View.generateViewId()); odd.setChecked(true);
        RadioButton even = radio("Even"); even.setId(View.generateViewId());
        RadioButton all = radio("Alles"); all.setId(View.generateViewId());
        sideGroup.addView(odd, weightParams()); sideGroup.addView(even, weightParams()); sideGroup.addView(all, weightParams());
        root.addView(sideGroup);

        TextView preview = smallText("Voorbeeld: 1, 3, 5, 7, 9 …");
        preview.setPadding(0, dp(8), 0, dp(12));
        root.addView(preview);

        sideGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == odd.getId()) preview.setText("Voorbeeld: 1, 3, 5, 7, 9 …");
            else if (checkedId == even.getId()) preview.setText("Voorbeeld: 2, 4, 6, 8, 10 …");
            else preview.setText("Voorbeeld: 1, 2, 3, 4, 5 …");
        });

        Button start = primaryButton("Start deze straat");
        start.setOnClickListener(v -> {
            String advisorText = advisor.getText().toString().trim();
            String municipalityText = municipality.getText().toString().trim();
            String streetText = street.getText().toString().trim();
            if (streetText.isEmpty()) {
                street.setError("Vul een straatnaam in");
                return;
            }
            int startNo, endNo;
            try {
                startNo = Integer.parseInt(from.getText().toString().trim());
                endNo = Integer.parseInt(to.getText().toString().trim());
            } catch (Exception e) {
                Toast.makeText(this, "Vul geldige huisnummers in.", Toast.LENGTH_SHORT).show();
                return;
            }
            if (startNo > endNo) {
                int temp = startNo; startNo = endNo; endNo = temp;
            }
            String side = odd.isChecked() ? SIDE_ODD : even.isChecked() ? SIDE_EVEN : SIDE_ALL;
            StreetSession s = new StreetSession();
            s.id = UUID.randomUUID().toString();
            s.advisor = advisorText;
            s.municipality = municipalityText;
            s.street = streetText;
            s.startNumber = startNo;
            s.endNumber = endNo;
            s.side = side;
            s.createdAt = System.currentTimeMillis();
            s.updatedAt = s.createdAt;
            s.currentIndex = 0;
            for (int n = startNo; n <= endNo; n++) {
                if (SIDE_ALL.equals(side) || (SIDE_ODD.equals(side) && n % 2 != 0) || (SIDE_EVEN.equals(side) && n % 2 == 0)) {
                    s.houses.add(new HouseVisit(n));
                }
            }
            if (s.houses.isEmpty()) {
                Toast.makeText(this, "Er zijn geen huisnummers in dit bereik voor deze kant.", Toast.LENGTH_LONG).show();
                return;
            }
            storage.save(s);
            showSession(s.id);
        });
        root.addView(start, fullButtonParams());

        setContentView(wrapInScroll(root));
    }

    private void showSession(String id) {
        currentScreen = "session";
        StreetSession s = storage.find(id);
        if (s == null) {
            showHome();
            return;
        }
        if (s.houses.isEmpty()) {
            showHome();
            return;
        }
        if (s.currentIndex < 0) s.currentIndex = 0;
        if (s.currentIndex >= s.houses.size()) s.currentIndex = s.houses.size() - 1;
        HouseVisit house = s.houses.get(s.currentIndex);

        LinearLayout root = baseScreen();
        addHeader(root, s.street, streetSubtitle(s), true);

        LinearLayout progressCard = card();
        TextView progressText = titleText(s.visitedCount() + " van " + s.houses.size() + " bezocht");
        progressText.setTextSize(18);
        progressCard.addView(progressText);
        ProgressBar progress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progress.setMax(s.houses.size());
        progress.setProgress(s.visitedCount());
        progress.setProgressTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        progress.setPadding(0, dp(10), 0, dp(8));
        progressCard.addView(progress, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(28)));
        TextView miniStats = smallText(
                "Niet thuis " + s.countStatus(STATUS_NOT_HOME) +
                "  •  Interesse " + s.countStatus(STATUS_INTEREST) +
                "  •  Afspraken " + s.countStatus(STATUS_APPOINTMENT));
        progressCard.addView(miniStats);
        root.addView(progressCard);

        LinearLayout houseCard = card();
        TextView small = smallText("HUIDIGE DEUR");
        small.setTypeface(Typeface.DEFAULT_BOLD);
        small.setTextColor(ACCENT);
        houseCard.addView(small);
        TextView number = titleText("Huisnummer " + house.number);
        number.setTextSize(32);
        number.setPadding(0, dp(4), 0, dp(4));
        houseCard.addView(number);
        TextView currentStatus = smallText("Status: " + house.status);
        houseCard.addView(currentStatus);
        root.addView(houseCard);

        EditText note = field("Notitie", "Bijv. terugkomen na 18u");
        note.setText(house.note == null ? "" : house.note);
        root.addView(labeled("Korte notitie (optioneel)", note));

        root.addView(label("Tik op het resultaat — de app gaat automatisch naar de volgende deur:"));
        addStatusRows(root, s, house, note);

        LinearLayout nav = horizontalRow();
        Button prev = secondaryButton("← Vorige");
        prev.setEnabled(s.currentIndex > 0);
        prev.setAlpha(prev.isEnabled() ? 1f : 0.45f);
        prev.setOnClickListener(v -> {
            saveCurrentNote(s, house, note);
            s.currentIndex = Math.max(0, s.currentIndex - 1);
            storage.save(s);
            showSession(s.id);
        });
        Button next = secondaryButton("Volgende →");
        next.setEnabled(s.currentIndex < s.houses.size() - 1);
        next.setAlpha(next.isEnabled() ? 1f : 0.45f);
        next.setOnClickListener(v -> {
            saveCurrentNote(s, house, note);
            s.currentIndex = Math.min(s.houses.size() - 1, s.currentIndex + 1);
            storage.save(s);
            showSession(s.id);
        });
        nav.addView(prev, weightParams()); nav.addView(next, weightParams());
        root.addView(nav);

        Button summary = secondaryButton("Bekijk samenvatting van deze straat");
        summary.setOnClickListener(v -> showSummary(s.id));
        root.addView(summary, fullButtonParams());

        setContentView(wrapInScroll(root));
    }

    private void addStatusRows(LinearLayout root, StreetSession s, HouseVisit house, EditText note) {
        String[][] statuses = {
                {STATUS_NOT_HOME, "Niet thuis"},
                {STATUS_NO_INTEREST, "Geen interesse"},
                {STATUS_INTEREST, "Interesse"},
                {STATUS_APPOINTMENT, "Afspraak gemaakt"},
                {STATUS_CUSTOMER, "Contract / klant"},
                {STATUS_LATER, "Later teruggaan"}
        };
        for (int i = 0; i < statuses.length; i += 2) {
            LinearLayout row = horizontalRow();
            for (int j = 0; j < 2 && i + j < statuses.length; j++) {
                String status = statuses[i + j][0];
                String label = statuses[i + j][1];
                Button b = statusButton(label, colorForStatus(status));
                b.setOnClickListener(v -> {
                    house.note = note.getText().toString().trim();
                    house.status = status;
                    house.updatedAt = System.currentTimeMillis();
                    s.updatedAt = house.updatedAt;
                    storage.save(s);
                    int nextIndex = findNextUnvisited(s, s.currentIndex + 1);
                    if (nextIndex < 0) nextIndex = findNextUnvisited(s, 0);
                    if (nextIndex >= 0) {
                        s.currentIndex = nextIndex;
                        storage.save(s);
                        showSession(s.id);
                    } else {
                        showSummary(s.id);
                    }
                });
                row.addView(b, weightParams());
            }
            root.addView(row);
        }
    }

    private void showSummary(String id) {
        currentScreen = "summary";
        StreetSession s = storage.find(id);
        if (s == null) { showHome(); return; }
        LinearLayout root = baseScreen();
        addHeader(root, "Straatsamenvatting", streetSubtitle(s), true);

        LinearLayout card = card();
        card.addView(summaryLine("Bezocht", s.visitedCount() + " / " + s.houses.size()));
        card.addView(summaryLine("Niet thuis", String.valueOf(s.countStatus(STATUS_NOT_HOME))));
        card.addView(summaryLine("Geen interesse", String.valueOf(s.countStatus(STATUS_NO_INTEREST))));
        card.addView(summaryLine("Interesse", String.valueOf(s.countStatus(STATUS_INTEREST))));
        card.addView(summaryLine("Afspraak gemaakt", String.valueOf(s.countStatus(STATUS_APPOINTMENT))));
        card.addView(summaryLine("Contract / klant", String.valueOf(s.countStatus(STATUS_CUSTOMER))));
        card.addView(summaryLine("Later teruggaan", String.valueOf(s.countStatus(STATUS_LATER))));
        root.addView(card);

        TextView todo = smallText("Nog niet bezocht: " + remainingNumbers(s));
        todo.setPadding(dp(4), dp(10), dp(4), dp(10));
        root.addView(todo);

        Button resume = primaryButton(s.visitedCount() == s.houses.size() ? "Straat opnieuw bekijken" : "Ga verder met deze straat");
        resume.setOnClickListener(v -> {
            int next = findNextUnvisited(s, 0);
            if (next >= 0) s.currentIndex = next;
            storage.save(s);
            showSession(s.id);
        });
        root.addView(resume, fullButtonParams());

        Button home = secondaryButton("Terug naar dashboard");
        home.setOnClickListener(v -> showHome());
        root.addView(home, fullButtonParams());

        setContentView(wrapInScroll(root));
    }

    private void showHistory() {
        currentScreen = "history";
        List<StreetSession> sessions = storage.loadAll();
        LinearLayout root = baseScreen();
        addHeader(root, "Straatgeschiedenis", "Alle straten die op dit toestel zijn aangemaakt.", true);

        if (sessions.isEmpty()) {
            root.addView(smallText("Nog geen straten geregistreerd."));
        }

        for (StreetSession s : sessions) {
            LinearLayout c = card();
            TextView t = titleText(s.street);
            t.setTextSize(19);
            c.addView(t);
            c.addView(smallText(streetSubtitle(s)));
            c.addView(smallText(s.visitedCount() + "/" + s.houses.size() + " bezocht  •  " + s.countStatus(STATUS_INTEREST) + " interesse  •  " + s.countStatus(STATUS_APPOINTMENT) + " afspraken"));

            LinearLayout actions = horizontalRow();
            Button open = secondaryButton("Open");
            open.setOnClickListener(v -> showSession(s.id));
            Button delete = dangerButton("Verwijder");
            delete.setOnClickListener(v -> new AlertDialog.Builder(this)
                    .setTitle("Straat verwijderen?")
                    .setMessage("Alle resultaten voor " + s.street + " worden van dit toestel verwijderd.")
                    .setNegativeButton("Annuleren", null)
                    .setPositiveButton("Verwijderen", (dialog, which) -> {
                        storage.delete(s.id);
                        showHistory();
                    }).show());
            actions.addView(open, weightParams()); actions.addView(delete, weightParams());
            c.addView(actions);
            root.addView(c);
        }
        setContentView(wrapInScroll(root));
    }

    private void exportCsv() {
        List<StreetSession> sessions = storage.loadAll();
        if (sessions.isEmpty()) {
            Toast.makeText(this, "Er zijn nog geen gegevens om te exporteren.", Toast.LENGTH_SHORT).show();
            return;
        }
        StringBuilder csv = new StringBuilder();
        csv.append("Datum;Sales advisor;Gemeente;Straat;Huisnummer;Kant;Status;Notitie\n");
        SimpleDateFormat fmt = new SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault());
        for (StreetSession s : sessions) {
            for (HouseVisit h : s.houses) {
                if (STATUS_NONE.equals(h.status)) continue;
                String date = h.updatedAt > 0 ? fmt.format(new Date(h.updatedAt)) : "";
                csv.append(escapeCsv(date)).append(';')
                        .append(escapeCsv(s.advisor)).append(';')
                        .append(escapeCsv(s.municipality)).append(';')
                        .append(escapeCsv(s.street)).append(';')
                        .append(h.number).append(';')
                        .append(escapeCsv(s.side)).append(';')
                        .append(escapeCsv(h.status)).append(';')
                        .append(escapeCsv(h.note)).append('\n');
            }
        }
        pendingCsv = csv.toString();
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("text/csv");
        String name = "sparki-door2door-" + new SimpleDateFormat("yyyyMMdd-HHmm", Locale.getDefault()).format(new Date()) + ".csv";
        intent.putExtra(Intent.EXTRA_TITLE, name);
        startActivityForResult(intent, EXPORT_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == EXPORT_REQUEST && resultCode == RESULT_OK && data != null && pendingCsv != null) {
            Uri uri = data.getData();
            if (uri == null) return;
            try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                if (out != null) {
                    out.write(pendingCsv.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this, "CSV opgeslagen.", Toast.LENGTH_LONG).show();
                }
            } catch (Exception e) {
                Toast.makeText(this, "Opslaan mislukt: " + e.getMessage(), Toast.LENGTH_LONG).show();
            }
            pendingCsv = null;
        }
    }

    private int findNextUnvisited(StreetSession s, int start) {
        for (int i = Math.max(0, start); i < s.houses.size(); i++) {
            if (STATUS_NONE.equals(s.houses.get(i).status)) return i;
        }
        return -1;
    }

    private void saveCurrentNote(StreetSession s, HouseVisit house, EditText note) {
        house.note = note.getText().toString().trim();
        s.updatedAt = System.currentTimeMillis();
        storage.save(s);
    }

    private String remainingNumbers(StreetSession s) {
        List<String> nums = new ArrayList<>();
        for (HouseVisit h : s.houses) if (STATUS_NONE.equals(h.status)) nums.add(String.valueOf(h.number));
        if (nums.isEmpty()) return "geen — straat is volledig verwerkt";
        if (nums.size() > 24) return String.join(", ", nums.subList(0, 24)) + " … (" + nums.size() + " resterend)";
        return String.join(", ", nums);
    }

    private String streetSubtitle(StreetSession s) {
        String location = s.municipality == null || s.municipality.trim().isEmpty() ? "" : s.municipality + "  •  ";
        String advisor = s.advisor == null || s.advisor.trim().isEmpty() ? "" : "  •  " + s.advisor;
        return location + s.side + " nummers " + s.startNumber + "–" + s.endNumber + advisor;
    }

    private String escapeCsv(String value) {
        if (value == null) return "";
        String v = value.replace("\"", "\"\"");
        if (v.contains(";") || v.contains("\n") || v.contains("\"")) return "\"" + v + "\"";
        return v;
    }

    // ---------- UI helpers ----------

    private LinearLayout baseScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(30));
        root.setBackgroundColor(BG);
        return root;
    }

    private ScrollView wrapInScroll(View child) {
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        sv.addView(child, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        return sv;
    }

    private void addHeader(LinearLayout root, String title, String subtitle, boolean showBack) {
        if (showBack) {
            Button back = textButton("← Terug");
            back.setOnClickListener(v -> showHome());
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, dp(42));
            bp.bottomMargin = dp(6);
            root.addView(back, bp);
        }
        TextView t = titleText(title);
        t.setTextSize(28);
        root.addView(t);
        TextView s = smallText(subtitle);
        s.setTextSize(14);
        s.setPadding(0, dp(5), 0, dp(16));
        root.addView(s);
    }

    private LinearLayout card() {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(16), dp(16), dp(16), dp(16));
        c.setBackground(roundRect(CARD, BORDER, 16));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.bottomMargin = dp(12);
        c.setLayoutParams(p);
        return c;
    }

    private LinearLayout statCard(String label, String value) {
        LinearLayout c = card();
        c.getLayoutParams().width = 0;
        TextView v = titleText(value);
        v.setTextSize(25);
        c.addView(v);
        c.addView(smallText(label));
        return c;
    }

    private TextView summaryLine(String left, String right) {
        TextView t = new TextView(this);
        t.setText(left + ":  " + right);
        t.setTextColor(TEXT);
        t.setTextSize(16);
        t.setPadding(0, dp(7), 0, dp(7));
        return t;
    }

    private LinearLayout labeled(String label, EditText field) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.addView(label(label));
        box.addView(field);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.bottomMargin = dp(10);
        box.setLayoutParams(p);
        return box;
    }

    private TextView label(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(TEXT);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextSize(14);
        t.setPadding(dp(2), dp(4), 0, dp(6));
        return t;
    }

    private EditText field(String contentDescription, String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setContentDescription(contentDescription);
        e.setTextColor(TEXT);
        e.setHintTextColor(Color.rgb(150, 158, 155));
        e.setTextSize(16);
        e.setSingleLine(false);
        e.setPadding(dp(12), dp(10), dp(12), dp(10));
        e.setBackground(roundRect(Color.WHITE, BORDER, 12));
        e.setMinHeight(dp(48));
        return e;
    }

    private EditText numberField(String contentDescription, String hint) {
        EditText e = field(contentDescription, hint);
        e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        e.setSingleLine(true);
        return e;
    }

    private RadioButton radio(String text) {
        RadioButton r = new RadioButton(this);
        r.setText(text);
        r.setTextColor(TEXT);
        r.setTextSize(14);
        r.setButtonTintList(android.content.res.ColorStateList.valueOf(ACCENT));
        return r;
    }

    private Button primaryButton(String text) {
        return button(text, ACCENT, Color.WHITE, ACCENT);
    }

    private Button secondaryButton(String text) {
        return button(text, Color.WHITE, TEXT, BORDER);
    }

    private Button dangerButton(String text) {
        return button(text, Color.WHITE, Color.rgb(166, 55, 55), Color.rgb(238, 199, 199));
    }

    private Button textButton(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(ACCENT_DARK);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setGravity(Gravity.LEFT | Gravity.CENTER_VERTICAL);
        b.setPadding(0, 0, 0, 0);
        b.setBackgroundColor(Color.TRANSPARENT);
        return b;
    }

    private Button statusButton(String text, int color) {
        Button b = button(text, color, Color.WHITE, color);
        b.setTextSize(14);
        b.setMinHeight(dp(58));
        return b;
    }

    private Button button(String text, int bg, int fg, int stroke) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(fg);
        b.setTextSize(15);
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setGravity(Gravity.CENTER);
        b.setPadding(dp(10), dp(9), dp(10), dp(9));
        b.setBackground(roundRect(bg, stroke, 13));
        return b;
    }

    private TextView titleText(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(TEXT);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private TextView smallText(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(MUTED);
        t.setTextSize(14);
        t.setLineSpacing(0, 1.12f);
        return t;
    }

    private LinearLayout horizontalRow() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setWeightSum(2f);
        return row;
    }

    private LinearLayout.LayoutParams weightParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        p.setMargins(dp(4), dp(4), dp(4), dp(4));
        return p;
    }

    private LinearLayout.LayoutParams fullButtonParams() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(54));
        p.setMargins(0, dp(5), 0, dp(5));
        return p;
    }

    private GradientDrawable roundRect(int fill, int stroke, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radiusDp));
        g.setStroke(dp(1), stroke);
        return g;
    }

    private int colorForStatus(String status) {
        switch (status) {
            case STATUS_NOT_HOME: return Color.rgb(222, 137, 53);
            case STATUS_NO_INTEREST: return Color.rgb(108, 117, 125);
            case STATUS_INTEREST: return Color.rgb(199, 153, 27);
            case STATUS_APPOINTMENT: return Color.rgb(63, 132, 78);
            case STATUS_CUSTOMER: return ACCENT;
            case STATUS_LATER: return Color.rgb(79, 106, 170);
            default: return ACCENT;
        }
    }

    private int dp(int value) {
        float density = getResources().getDisplayMetrics().density;
        return Math.round(value * density);
    }
}
