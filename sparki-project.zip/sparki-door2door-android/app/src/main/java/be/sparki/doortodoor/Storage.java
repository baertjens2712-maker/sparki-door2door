package be.sparki.doortodoor;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class Storage {
    private static final String PREFS = "sparki_door2door";
    private static final String KEY = "sessions";
    private final SharedPreferences prefs;

    public Storage(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public List<StreetSession> loadAll() {
        List<StreetSession> list = new ArrayList<>();
        String raw = prefs.getString(KEY, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.optJSONObject(i);
                if (obj != null) list.add(StreetSession.fromJson(obj));
            }
        } catch (Exception ignored) { }
        list.sort(Comparator.comparingLong((StreetSession s) -> s.updatedAt).reversed());
        return list;
    }

    public StreetSession find(String id) {
        for (StreetSession s : loadAll()) if (s.id.equals(id)) return s;
        return null;
    }

    public void save(StreetSession session) {
        List<StreetSession> list = loadAll();
        boolean found = false;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).id.equals(session.id)) {
                list.set(i, session);
                found = true;
                break;
            }
        }
        if (!found) list.add(session);
        persist(list);
    }

    public void delete(String id) {
        List<StreetSession> list = loadAll();
        list.removeIf(s -> s.id.equals(id));
        persist(list);
    }

    private void persist(List<StreetSession> list) {
        JSONArray arr = new JSONArray();
        for (StreetSession s : list) {
            try { arr.put(s.toJson()); } catch (Exception ignored) { }
        }
        prefs.edit().putString(KEY, arr.toString()).apply();
    }
}
