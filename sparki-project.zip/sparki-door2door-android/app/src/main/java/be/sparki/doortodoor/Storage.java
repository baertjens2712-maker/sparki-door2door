package be.sparki.doortodoor;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Storage {
    private static final String PREFS = "sparki_door2door";
    private static final String KEY = "sessions";
    private final SharedPreferences prefs;

    public Storage(Context context) {
        prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public List<StreetSession> loadAll() {
        List<StreetSession> list = new ArrayList<>();
        String raw = prefs.getString(KEY, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.optJSONObject(i);
                if (obj != null) list.add(StreetSession.fromJson(obj));
            }
        } catch (Exception ignored) { }
        list.sort(Comparator.comparingLong((StreetSession s) -> s.updatedAt).reversed());
        return list;
    }

    public StreetSession find(String id) {
        for (StreetSession s : loadAll()) if (s.id.equals(id)) return s;
        return null;
    }

    public void save(StreetSession session) {
        List<StreetSession> list = loadAll();
        boolean found = false;
        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).id.equals(session.id)) {
                list.set(i, session);
                found = true;
                break;
            }
        }
        if (!found) list.add(session);
        persist(list);
    }

    public void delete(String id) {
        List<StreetSession> list = loadAll();
        list.removeIf(s -> s.id.equals(id));
        persist(list);
    }

    public String exportJson() {
        JSONArray arr = new JSONArray();
        for (StreetSession s : loadAll()) {
            try { arr.put(s.toJson()); } catch (Exception ignored) { }
        }
        return arr.toString();
    }

    public int mergeJson(String raw) {
        List<StreetSession> current = loadAll();
        Map<String, StreetSession> byId = new HashMap<>();
        for (StreetSession s : current) byId.put(s.id, s);
        int changed = 0;

        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject obj = arr.optJSONObject(i);
                if (obj == null) continue;
                StreetSession incoming = StreetSession.fromJson(obj);
                if (incoming.id == null || incoming.id.isEmpty()) continue;

                StreetSession existing = byId.get(incoming.id);
                if (existing == null) {
                    current.add(incoming);
                    byId.put(incoming.id, incoming);
                    changed++;
                    continue;
                }

                Map<Integer, HouseVisit> existingHouses = new HashMap<>();
                for (HouseVisit h : existing.houses) existingHouses.put(h.number, h);
                for (HouseVisit remoteHouse : incoming.houses) {
                    HouseVisit localHouse = existingHouses.get(remoteHouse.number);
                    if (localHouse == null) {
                        existing.houses.add(remoteHouse);
                        changed++;
                    } else {
                        if (remoteHouse.updatedAt > localHouse.updatedAt) {
                            localHouse.status = remoteHouse.status;
                            localHouse.note = remoteHouse.note;
                            localHouse.updatedAt = remoteHouse.updatedAt;
                            localHouse.appointmentAt = remoteHouse.appointmentAt;
                            changed++;
                        }
                        if (!localHouse.hasLocation() && remoteHouse.hasLocation()) {
                            localHouse.latitude = remoteHouse.latitude;
                            localHouse.longitude = remoteHouse.longitude;
                        }
                    }
                }

                if (incoming.updatedAt > existing.updatedAt) {
                    existing.advisor = incoming.advisor;
                    existing.municipality = incoming.municipality;
                    existing.street = incoming.street;
                    existing.startNumber = incoming.startNumber;
                    existing.endNumber = incoming.endNumber;
                    existing.side = incoming.side;
                    existing.updatedAt = incoming.updatedAt;
                    existing.currentIndex = Math.max(0, Math.min(incoming.currentIndex, Math.max(0, existing.houses.size() - 1)));
                }
                if (Math.abs(existing.mapCenterLat) < 0.000001 && Math.abs(incoming.mapCenterLat) > 0.000001) {
                    existing.mapCenterLat = incoming.mapCenterLat;
                    existing.mapCenterLon = incoming.mapCenterLon;
                }
            }
            persist(current);
        } catch (Exception e) {
            return -1;
        }
        return changed;
    }

    private void persist(List<StreetSession> list) {
        JSONArray arr = new JSONArray();
        for (StreetSession s : list) {
            try { arr.put(s.toJson()); } catch (Exception ignored) { }
        }
        prefs.edit().putString(KEY, arr.toString()).apply();
    }
}
