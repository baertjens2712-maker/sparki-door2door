package be.sparki.doortodoor;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class StreetSession {
    public String id;
    public String advisor;
    public String municipality;
    public String street;
    public int startNumber;
    public int endNumber;
    public String side;
    public long createdAt;
    public long updatedAt;
    public int currentIndex;
    public double mapCenterLat;
    public double mapCenterLon;
    public final List<HouseVisit> houses = new ArrayList<>();

    public JSONObject toJson() throws JSONException {
        JSONObject obj = new JSONObject();
        obj.put("id", id);
        obj.put("advisor", advisor);
        obj.put("municipality", municipality);
        obj.put("street", street);
        obj.put("startNumber", startNumber);
        obj.put("endNumber", endNumber);
        obj.put("side", side);
        obj.put("createdAt", createdAt);
        obj.put("updatedAt", updatedAt);
        obj.put("currentIndex", currentIndex);
        obj.put("mapCenterLat", mapCenterLat);
        obj.put("mapCenterLon", mapCenterLon);

        JSONArray arr = new JSONArray();
        for (HouseVisit h : houses) arr.put(h.toJson());
        obj.put("houses", arr);
        return obj;
    }

    public static StreetSession fromJson(JSONObject obj) {
        StreetSession s = new StreetSession();
        s.id = obj.optString("id", "");
        s.advisor = obj.optString("advisor", "");
        s.municipality = obj.optString("municipality", "");
        s.street = obj.optString("street", "");
        s.startNumber = obj.optInt("startNumber", 1);
        s.endNumber = obj.optInt("endNumber", 1);
        s.side = obj.optString("side", MainActivity.SIDE_ODD);
        s.createdAt = obj.optLong("createdAt", System.currentTimeMillis());
        s.updatedAt = obj.optLong("updatedAt", s.createdAt);
        s.currentIndex = obj.optInt("currentIndex", 0);
        s.mapCenterLat = obj.optDouble("mapCenterLat", 0d);
        s.mapCenterLon = obj.optDouble("mapCenterLon", 0d);

        JSONArray arr = obj.optJSONArray("houses");
        if (arr != null) {
            for (int i = 0; i < arr.length(); i++) {
                JSONObject item = arr.optJSONObject(i);
                if (item != null) s.houses.add(HouseVisit.fromJson(item));
            }
        }
        if (s.currentIndex < 0 || s.currentIndex >= Math.max(1, s.houses.size())) s.currentIndex = 0;
        return s;
    }

    public int countStatus(String status) {
        int count = 0;
        for (HouseVisit h : houses) if (status.equals(h.status)) count++;
        return count;
    }

    public int visitedCount() {
        int count = 0;
        for (HouseVisit h : houses) if (!MainActivity.STATUS_NONE.equals(h.status)) count++;
        return count;
    }

    public int locatedCount() {
        int count = 0;
        for (HouseVisit h : houses) if (h.hasLocation()) count++;
        return count;
    }
}
